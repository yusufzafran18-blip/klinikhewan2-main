import React, { useState } from 'react';
import { PembelianSupplier, Supplier, Barang } from '../../types';
import { ShoppingCart, Plus, Search, FileSpreadsheet } from 'lucide-react';
import { exportToExcel } from '../../services/excel';

interface PembelianViewProps {
  pembelianList: PembelianSupplier[];
  supplierList: Supplier[];
  barangList: Barang[];
  onSavePembelian: (po: PembelianSupplier) => void;
}

export const PembelianView: React.FC<PembelianViewProps> = ({
  pembelianList = [],
  supplierList = [],
  barangList = [],
  onSavePembelian,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [supplierId, setSupplierId] = useState(supplierList[0]?.id || '');
  const [noFaktur, setNoFaktur] = useState('PO-2026-001');

  const handleExportExcel = () => {
    const data = pembelianList.map((p) => ({
      'No. Faktur': p.noFakturSupplier,
      'Tanggal': p.tanggal,
      'Supplier': supplierList.find((s) => s.id === p.supplierId)?.namaSupplier || '-',
      'Total Nominal': p.totalNominal,
      'Status': p.status,
    }));
    exportToExcel(data, 'Laporan_Pembelian_PO_Supplier');
  };

  return (
    <div className="space-y-6">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center space-x-2">
            <ShoppingCart className="w-5 h-5 text-indigo-600" />
            <h2 className="text-lg font-bold text-slate-800">Pembelian & Stock In (PO Supplier)</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">Pencatatan faktur barang masuk dari distributor farmasi / distributor pakan</p>
        </div>

        <button
          onClick={handleExportExcel}
          className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-200 flex items-center space-x-1.5"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Export Excel</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200/80 text-slate-500 uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="p-4">No. Faktur & Tanggal</th>
                <th className="p-4">Distributor / Supplier</th>
                <th className="p-4">Item Masuk</th>
                <th className="p-4">Total Nominal</th>
                <th className="p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {pembelianList.length === 0 ? (
                <tr><td colSpan={5} className="p-8 text-center text-slate-400">Belum ada riwayat PO pembelian supplier.</td></tr>
              ) : (
                pembelianList.map((p) => {
                  const supplier = supplierList.find((s) => s.id === p.supplierId);

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80">
                      <td className="p-4">
                        <span className="font-bold text-slate-800 block">{p.noFakturSupplier}</span>
                        <span className="text-[10px] text-slate-400">{p.tanggal}</span>
                      </td>
                      <td className="p-4 font-bold text-slate-800">{supplier?.namaSupplier || 'Supplier'}</td>
                      <td className="p-4">
                        {(p.items || []).map((i, idx) => (
                          <div key={idx} className="text-[11px] text-slate-600">• {i.namaBarang} ({i.jumlah} x Rp {(i.hargaBeliSatuan || 0).toLocaleString('id-ID')})</div>
                        ))}
                      </td>
                      <td className="p-4 font-black text-slate-900">Rp {(p.totalNominal || 0).toLocaleString('id-ID')}</td>
                      <td className="p-4">
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-bold">
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
