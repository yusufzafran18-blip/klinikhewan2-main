import React, { useState } from 'react';
import { Transaksi, DataKlinik, AppSettings } from '../../types';
import { Printer, X, CheckCircle, Share2, MessageSquare } from 'lucide-react';
import { generateWaLink, waTemplates } from '../../services/wa';

interface ThermalReceiptModalProps {
  transaksi: Transaksi;
  klinik: DataKlinik;
  settings: AppSettings;
  onClose: () => void;
}

export const ThermalReceiptModal: React.FC<ThermalReceiptModalProps> = ({
  transaksi,
  klinik,
  settings,
  onClose,
}) => {
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(settings.printerThermalWidth || '58mm');

  const handlePrint = () => {
    const prevTitle = document.title;
    document.title = `Nota_${transaksi.noNota || 'Kasir'}_${klinik.namaKlinik}`;
    window.print();
    setTimeout(() => {
      document.title = prevTitle;
    }, 500);
  };

  const handleSendWA = () => {
    if (transaksi.pasienId) {
      const waText = waTemplates.receiptSummary(transaksi, klinik);
      // fallback phone number
      const phone = '081234567890';
      window.open(generateWaLink(phone, waText), '_blank');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full p-6 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header Control */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900">Cetak Nota Kasir Thermal</h3>
            <p className="text-xs text-slate-500">Pilih format kertas & cetak langsung</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toggle 58mm / 80mm */}
        <div className="my-4 flex items-center justify-center space-x-2 bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setPaperWidth('58mm')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              paperWidth === '58mm'
                ? 'bg-white text-indigo-600 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Thermal 58 mm (Kecil)
          </button>
          <button
            onClick={() => setPaperWidth('80mm')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              paperWidth === '80mm'
                ? 'bg-white text-indigo-600 shadow-xs'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Thermal 80 mm (Standar)
          </button>
        </div>

        {/* Printable Thermal Container Area */}
        <div className="bg-slate-100 p-4 rounded-xl overflow-x-auto flex justify-center">
          <div
            id="thermal-receipt-printable"
            className={`bg-white font-mono text-[11px] leading-tight text-slate-900 p-3 shadow-md border border-slate-300 ${
              paperWidth === '58mm' ? 'w-[230px]' : 'w-[310px]'
            }`}
          >
            {/* Header Nota */}
            <div className="text-center font-bold uppercase mb-1 flex flex-col items-center">
              {klinik.logoUrl && (
                <img
                  src={klinik.logoUrl}
                  alt={klinik.namaKlinik}
                  className="w-12 h-12 object-contain mx-auto mb-1 rounded-md"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              )}
              <p className="text-xs font-extrabold">{klinik.namaKlinik}</p>
              <p className="font-normal text-[10px] lowercase normal-case">{klinik.alamat}</p>
              <p className="font-normal text-[10px]">Telp: {klinik.noTelp || (klinik as any).telepon}</p>
            </div>

            <div className="border-b border-dashed border-slate-400 my-2"></div>

            {/* Info Transaksi */}
            <div className="space-y-0.5 text-[10px]">
              <div className="flex justify-between">
                <span>No. Nota:</span>
                <span className="font-bold">{transaksi.noNota}</span>
              </div>
              <div className="flex justify-between">
                <span>Tgl/Jam:</span>
                <span>{transaksi.tanggal}</span>
              </div>
              <div className="flex justify-between">
                <span>Pelanggan:</span>
                <span className="font-semibold truncate max-w-[120px]">{transaksi.namaPelanggan}</span>
              </div>
              <div className="flex justify-between">
                <span>Metode:</span>
                <span className="font-semibold">{transaksi.metodePembayaran}</span>
              </div>
            </div>

            <div className="border-b border-dashed border-slate-400 my-2"></div>

            {/* Items Table */}
            <div className="space-y-1.5 text-[10px]">
              {(transaksi.items || []).map((item, idx) => (
                <div key={idx} className="space-y-0.5">
                  <p className="font-semibold">{item.namaItem}</p>
                  <div className="flex justify-between text-slate-600 pl-2">
                    <span>{item.jumlah} x Rp {(item.hargaSatuan || 0).toLocaleString('id-ID')}</span>
                    <span className="font-bold text-slate-900">Rp {(item.subtotal || 0).toLocaleString('id-ID')}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-b border-dashed border-slate-400 my-2"></div>

            {/* Summary Pricing */}
            <div className="space-y-1 text-[10px]">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>Rp {(transaksi.subtotal || 0).toLocaleString('id-ID')}</span>
              </div>
              {(transaksi.diskon || 0) > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Diskon:</span>
                  <span>-Rp {(transaksi.diskon || 0).toLocaleString('id-ID')}</span>
                </div>
              )}
              {(transaksi.pajak || 0) > 0 && (
                <div className="flex justify-between">
                  <span>Pajak ({settings.pPNPersen}%):</span>
                  <span>Rp {(transaksi.pajak || 0).toLocaleString('id-ID')}</span>
                </div>
              )}
              <div className="border-b border-solid border-slate-400 my-1"></div>
              <div className="flex justify-between text-xs font-bold">
                <span>TOTAL:</span>
                <span>Rp {(transaksi.grandTotal || 0).toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between">
                <span>Bayar:</span>
                <span>Rp {(transaksi.jumlahBayar || 0).toLocaleString('id-ID')}</span>
              </div>
              <div className="flex justify-between">
                <span>Kembali:</span>
                <span>Rp {(transaksi.kembalian || 0).toLocaleString('id-ID')}</span>
              </div>
            </div>

            <div className="border-b border-dashed border-slate-400 my-2"></div>

            {/* Footer Nota */}
            <div className="text-center text-[9px] text-slate-600 whitespace-pre-line mt-2">
              {klinik.footerNota}
            </div>
            <p className="text-center text-[8px] text-slate-400 mt-2">VetCare POS v1.0.0</p>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="mt-5 flex items-center space-x-3">
          <button
            onClick={handlePrint}
            className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center justify-center space-x-2 shadow-md shadow-indigo-200 transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Nota Thermal</span>
          </button>
          <button
            onClick={handleSendWA}
            className="py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center space-x-2 shadow-md shadow-emerald-200 transition-all"
            title="Kirim Ringkasan Nota via WhatsApp"
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden sm:inline">Kirim WA</span>
          </button>
        </div>

      </div>
    </div>
  );
};
