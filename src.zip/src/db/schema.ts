import { pgTable, text, timestamp, boolean, integer, json, decimal } from 'drizzle-orm/pg-core';

// 1. Users Table
export const users = pgTable('users', {
  id: text('id').primaryKey(),
  username: text('username').notNull().unique(),
  password: text('password').notNull().default('admin123'),
  nama: text('nama').notNull(),
  email: text('email').notNull().unique(),
  role: text('role').notNull().default('staf'),
  noHp: text('no_hp'),
  aktif: boolean('aktif').notNull().default(true),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 2. Dokter Table
export const dokter = pgTable('dokter', {
  id: text('id').primaryKey(),
  sip: text('sip').notNull().unique(),
  nama: text('nama').notNull(),
  spesialisasi: text('spesialisasi').notNull(),
  noHp: text('no_hp').notNull(),
  email: text('email'),
  jadwal: text('jadwal'),
  aktif: boolean('aktif').notNull().default(true),
  fotoUrl: text('foto_url'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 3. Pasien Table
export const pasien = pgTable('pasien', {
  id: text('id').primaryKey(),
  kodePasien: text('kode_pasien').notNull().unique(),
  namaHewan: text('nama_hewan').notNull(),
  jenisHewan: text('jenis_hewan').notNull(),
  ras: text('ras'),
  jenisKelamin: text('jenis_kelamin').notNull(),
  tanggalLahir: text('tanggal_lahir').notNull(),
  umurFormat: text('umur_format'),
  warna: text('warna'),
  noMicrochip: text('no_microchip'),
  namaOwner: text('nama_owner').notNull(),
  noHpOwner: text('no_hp_owner').notNull(),
  alamatOwner: text('alamat_owner').notNull(),
  emailOwner: text('email_owner'),
  foto: text('foto'),
  catatanKhusus: text('catatan_khusus'),
  riwayatAlergi: text('riwayat_alergi'),
  riwayatPenyakit: text('riwayat_penyakit'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 4. Barang Table
export const barang = pgTable('barang', {
  id: text('id').primaryKey(),
  kode: text('kode').notNull().unique(),
  nama: text('nama').notNull(),
  kategori: text('kategori').notNull().default('Obat'),
  satuan: text('satuan').notNull().default('Pcs'),
  hargaBeli: decimal('harga_beli', { precision: 12, scale: 2 }).notNull().default('0'),
  hargaJual: decimal('harga_jual', { precision: 12, scale: 2 }).notNull().default('0'),
  stok: integer('stok').notNull().default(0),
  stokMinimum: integer('stok_minimum').notNull().default(5),
  tanggalKadaluarsa: text('tanggal_kadaluarsa'),
  statusKadaluarsa: text('status_kadaluarsa').default('Aman'),
  catatan: text('catatan'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 5. Tindakan Table
export const tindakan = pgTable('tindakan', {
  id: text('id').primaryKey(),
  kode: text('kode').notNull().unique(),
  nama: text('nama').notNull(),
  kategori: text('kategori').notNull(),
  tarif: decimal('tarif', { precision: 12, scale: 2 }).notNull().default('0'),
  deskripsi: text('deskripsi'),
  estimasiMenit: integer('estimasi_menit').default(15),
  createdAt: timestamp('created_at').defaultNow(),
});

// 6. Pakan Table
export const pakan = pgTable('pakan', {
  id: text('id').primaryKey(),
  kode: text('kode').notNull().unique(),
  nama: text('nama').notNull(),
  jenisHewan: text('jenis_hewan').notNull(),
  hargaPerHari: decimal('harga_per_hari', { precision: 12, scale: 2 }).notNull().default('0'),
  catatan: text('catatan'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 7. Spesies Table
export const spesies = pgTable('spesies', {
  id: text('id').primaryKey(),
  nama: text('nama').notNull(),
  kategori: text('kategori').notNull(),
  deskripsi: text('deskripsi'),
  rasUmum: json('ras_umum'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 8. Pendaftaran Table
export const pendaftaran = pgTable('pendaftaran', {
  id: text('id').primaryKey(),
  nomorAntrian: text('nomor_antrian').notNull(),
  pasienId: text('pasien_id').notNull(),
  dokterId: text('dokter_id').notNull(),
  tanggal: text('tanggal').notNull(),
  keluhan: text('keluhan').notNull(),
  status: text('status').notNull().default('Menunggu'),
  jenisLayanan: text('jenis_layanan').default('Pemeriksaan Umum'),
  catatan: text('catatan'),
  waktuDaftar: text('waktu_daftar'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 9. Rekam Medis Table
export const rekamMedis = pgTable('rekam_medis', {
  id: text('id').primaryKey(),
  noRekamMedis: text('no_rekam_medis').notNull().unique(),
  tanggal: text('tanggal').notNull(),
  pasienId: text('pasien_id').notNull(),
  dokterId: text('dokter_id').notNull(),
  subjektif: text('subjektif').default('-'),
  objektif: text('objektif').default('-'),
  assesment: text('assesment').default('-'),
  diagnosa: text('diagnosa').default('-'),
  plan: text('plan').default('-'),
  suhu: text('suhu'),
  beratBadan: text('berat_badan'),
  resep: json('resep'),
  tindakan: json('tindakan'),
  totalBiaya: decimal('total_biaya', { precision: 12, scale: 2 }).notNull().default('0'),
  statusPembayaran: text('status_pembayaran').notNull().default('Belum Bayar'),
  catatan: text('catatan'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 10. Rawat Inap Table
export const rawatInap = pgTable('rawat_inap', {
  id: text('id').primaryKey(),
  noKamar: text('no_kamar').notNull(),
  pasienId: text('pasien_id').notNull(),
  dokterId: text('dokter_id').notNull(),
  tanggalMasuk: text('tanggal_masuk').notNull(),
  tanggalKeluar: text('tanggal_keluar'),
  status: text('status').notNull().default('Dalam Perawatan'),
  diagnosa: text('diagnosa').default('-'),
  pakanId: text('pakan_id'),
  catatan: text('catatan'),
  dailyNotes: json('daily_notes'),
  monitoringLogs: json('monitoring_logs'),
  totalBiaya: decimal('total_biaya', { precision: 12, scale: 2 }).default('0'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 11. Janji Temu Table
export const janjiTemu = pgTable('janji_temu', {
  id: text('id').primaryKey(),
  pasienId: text('pasien_id').notNull(),
  dokterId: text('dokter_id').notNull(),
  tanggal: text('tanggal').notNull(),
  waktu: text('waktu').default('09:00'),
  status: text('status').notNull().default('Terjadwal'),
  keluhan: text('keluhan').default('-'),
  jenisLayanan: text('jenis_layanan').default('Kontrol Ulang'),
  reminderSent: boolean('reminder_sent').default(false),
  createdAt: timestamp('created_at').defaultNow(),
});

// 12. Vaksinasi Table
export const vaksinasi = pgTable('vaksinasi', {
  id: text('id').primaryKey(),
  pasienId: text('pasien_id').notNull(),
  namaVaksin: text('nama_vaksin').notNull(),
  tanggalDiberikan: text('tanggal_diberikan').default(''),
  tanggalBerikutnya: text('tanggal_berikutnya'),
  dokterId: text('dokter_id'),
  batchNumber: text('batch_number'),
  catatan: text('catatan'),
  status: text('status').notNull().default('Selesai'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 13. Transaksi Table
export const transaksi = pgTable('transaksi', {
  id: text('id').primaryKey(),
  kodeTransaksi: text('kode_transaksi').notNull().unique(),
  tanggal: text('tanggal').notNull(),
  pasienId: text('pasien_id'),
  items: json('items').notNull(),
  subtotal: decimal('subtotal', { precision: 12, scale: 2 }).notNull().default('0'),
  diskon: decimal('diskon', { precision: 12, scale: 2 }).notNull().default('0'),
  pajak: decimal('pajak', { precision: 12, scale: 2 }).notNull().default('0'),
  total: decimal('total', { precision: 12, scale: 2 }).notNull().default('0'),
  metodePembayaran: text('metode_pembayaran').notNull().default('Tunai'),
  status: text('status').notNull().default('Lunas'),
  kasir: text('kasir').notNull(),
  catatan: text('catatan'),
  sourceType: text('source_type'),
  sourceId: text('source_id'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 14. Pembelian Table
export const pembelian = pgTable('pembelian', {
  id: text('id').primaryKey(),
  nomorPO: text('nomor_po').notNull().unique(),
  supplierId: text('supplier_id').notNull(),
  tanggal: text('tanggal').notNull(),
  items: json('items').notNull(),
  totalHarga: decimal('total_harga', { precision: 12, scale: 2 }).notNull().default('0'),
  status: text('status').notNull().default('Selesai'),
  catatan: text('catatan'),
  createdAt: timestamp('created_at').defaultNow(),
});

// 15. Supplier Table
export const supplier = pgTable('supplier', {
  id: text('id').primaryKey(),
  nama: text('nama').notNull(),
  kontak: text('kontak').notNull(),
  noHp: text('no_hp').notNull(),
  email: text('email'),
  alamat: text('alamat').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// 16. Feedback Table
export const feedback = pgTable('feedback', {
  id: text('id').primaryKey(),
  pasienId: text('pasien_id').notNull(),
  transaksiId: text('transaksi_id'),
  rating: integer('rating').notNull().default(5),
  catatan: text('catatan'),
  tanggal: text('tanggal').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

// 17. App Config & Settings Tables
export const clinicStore = pgTable('clinic_store', {
  key: text('key').primaryKey(),
  value: json('value').notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});
