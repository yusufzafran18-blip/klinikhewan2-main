import React, { useState, useEffect } from 'react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar, ActiveTab } from './components/layout/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { PendaftaranView } from './components/views/PendaftaranView';
import { PasienView } from './components/views/PasienView';
import { RekamMedisView } from './components/views/RekamMedisView';
import { RawatJalanView } from './components/views/RawatJalanView';
import { RawatInapView } from './components/views/RawatInapView';
import { JanjiTemuView } from './components/views/JanjiTemuView';
import { KasirView } from './components/views/KasirView';
import { PenjualanDirectView } from './components/views/PenjualanDirectView';
import { InventoryView } from './components/views/InventoryView';
import { PembelianView } from './components/views/PembelianView';
import { MasterDataView } from './components/views/MasterDataView';
import { LaporanKeuanganView } from './components/views/LaporanKeuanganView';
import { LaporanLabaPenjualanView } from './components/views/LaporanLabaPenjualanView';
import { LaporanTrenPenyakitView } from './components/views/LaporanTrenPenyakitView';
import { FeedbackView } from './components/views/FeedbackView';
import { PengaturanView } from './components/views/PengaturanView';
import { HakAksesView } from './components/views/HakAksesView';
import { WhatsAppIntegrationView } from './components/views/WhatsAppIntegrationView';
import { LoginView } from './components/views/LoginView';
import { AccessDeniedView } from './components/views/AccessDeniedView';
import { getModulePermissions } from './utils/rbac';

import { storageService } from './services/storage';
import {
  User, Pasien, Pendaftaran, RekamMedis, RawatInap, Transaksi,
  Barang, JanjiTemu, Supplier, PembelianSupplier, Dokter, Tindakan,
  PakanHewan, RiwayatVaksinasi, FeedbackPelanggan, DataKlinik, AppSettings,
  MonitoringLog, Spesies, RBACConfig, WhatsAppConfig, WhatsAppTemplate, WhatsAppLog
} from './types';

export function App() {
  // State Initialization from LocalStorage
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [activeUser, setActiveUser] = useState<User | null>(() => storageService.getActiveUser());
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // Auth Handlers
  const handleLogin = (user: User) => {
    setActiveUser(user);
    storageService.setActiveUser(user);
  };

  const handleLogout = () => {
    setActiveUser(null);
    storageService.logout();
  };

  // Data Collections
  const [pasienList, setPasienList] = useState<Pasien[]>([]);
  const [pendaftaranList, setPendaftaranList] = useState<Pendaftaran[]>([]);
  const [rekamMedisList, setRekamMedisList] = useState<RekamMedis[]>([]);
  const [rawatInapList, setRawatInapList] = useState<RawatInap[]>([]);
  const [transaksiList, setTransaksiList] = useState<Transaksi[]>([]);
  const [barangList, setBarangList] = useState<Barang[]>([]);
  const [janjiTemuList, setJanjiTemuList] = useState<JanjiTemu[]>([]);
  const [supplierList, setSupplierList] = useState<Supplier[]>([]);
  const [pembelianList, setPembelianList] = useState<PembelianSupplier[]>([]);
  const [dokterList, setDokterList] = useState<Dokter[]>([]);
  const [tindakanList, setTindakanList] = useState<Tindakan[]>([]);
  const [pakanList, setPakanList] = useState<PakanHewan[]>([]);
  const [spesiesList, setSpesiesList] = useState<Spesies[]>([]);
  const [vaksinasiList, setVaksinasiList] = useState<RiwayatVaksinasi[]>([]);
  const [feedbackList, setFeedbackList] = useState<FeedbackPelanggan[]>([]);
  const [userList, setUserList] = useState<User[]>([]);
  const [rbacConfig, setRbacConfig] = useState<RBACConfig>(() => storageService.getRBACConfig());
  const [klinik, setKlinik] = useState<DataKlinik>(storageService.getKlinikData());
  const [settings, setSettings] = useState<AppSettings>(storageService.getAppSettings());
  const [waConfig, setWaConfig] = useState<WhatsAppConfig>(() => storageService.getWhatsAppConfig());
  const [waTemplates, setWaTemplates] = useState<WhatsAppTemplate[]>([]);
  const [waLogs, setWaLogs] = useState<WhatsAppLog[]>([]);

  // Navigation badge counts
  const queueCount = pendaftaranList.filter((p) => p.status === 'Antri' || p.status === 'Diperiksa').length;
  const inpatientCount = rawatInapList.filter((i) => i.status === 'Dirawat').length;

  // Inter-tab flow state (e.g. start examining patient from queue)
  const [activePendaftaranForSOAP, setActivePendaftaranForSOAP] = useState<Pendaftaran | null>(null);

  // Load All Data on Mount or Reload
  const loadAllData = () => {
    setPasienList(storageService.getPasienList());
    setPendaftaranList(storageService.getPendaftaranList());
    setRekamMedisList(storageService.getRekamMedisList());
    setRawatInapList(storageService.getRawatInapList());
    setTransaksiList(storageService.getTransaksiList());
    setBarangList(storageService.getBarangList());
    setJanjiTemuList(storageService.getJanjiTemuList());
    setSupplierList(storageService.getSupplierList());
    setPembelianList(storageService.getPembelianList());
    setDokterList(storageService.getDokterList());
    setTindakanList(storageService.getTindakanList());
    setPakanList(storageService.getPakanList());
    setSpesiesList(storageService.getSpesiesList());
    setVaksinasiList(storageService.getVaksinasiList());
    setFeedbackList(storageService.getFeedbackList());
    setUserList(storageService.getUserList());
    setRbacConfig(storageService.getRBACConfig());
    setKlinik(storageService.getKlinikData());
    setSettings(storageService.getAppSettings());
    setWaConfig(storageService.getWhatsAppConfig());
    setWaTemplates(storageService.getWhatsAppTemplates());
    setWaLogs(storageService.getWhatsAppLogs());
  };

  useEffect(() => {
    storageService.initStorage().then(() => {
      loadAllData();
    });
    loadAllData();

    const unsubscribe = storageService.subscribe(() => {
      loadAllData();
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Role Switching Handler
  const handleRoleChange = (role: any) => {
    if (!activeUser) return;
    const updated = { ...activeUser, role };
    setActiveUser(updated);
    storageService.setActiveUser(updated);
  };

  // Handlers for Pendaftaran
  const handleSavePendaftaran = (pdf: Pendaftaran) => {
    const updated = [pdf, ...pendaftaranList];
    setPendaftaranList(updated);
    storageService.savePendaftaranList(updated);
  };

  const handleUpdatePendaftaranStatus = (id: string, status: 'Antri' | 'Diperiksa' | 'Selesai' | 'Batal') => {
    const updated = pendaftaranList.map((p) => p.id === id ? { ...p, status } : p);
    setPendaftaranList(updated);
    storageService.savePendaftaranList(updated);
  };

  const handleStartExamine = (pendaftaran: Pendaftaran) => {
    setActivePendaftaranForSOAP(pendaftaran);
    setActiveTab('rekam_medis');
  };

  // Handlers for Pasien
  const handleSavePasien = (pasien: Pasien) => {
    const exists = pasienList.some((p) => p.id === pasien.id);
    const updated = exists
      ? pasienList.map((p) => p.id === pasien.id ? pasien : p)
      : [pasien, ...pasienList];
    setPasienList(updated);
    storageService.savePasienList(updated);
  };

  const handleDeletePasien = (id: string) => {
    const updated = pasienList.filter((p) => p.id !== id);
    setPasienList(updated);
    storageService.savePasienList(updated);
  };

  // Handlers for Rekam Medis
  const handleSaveRekamMedis = (rm: RekamMedis) => {
    const updatedRM = [rm, ...rekamMedisList];
    setRekamMedisList(updatedRM);
    storageService.saveRekamMedisList(updatedRM);

    // If originated from pendaftaran queue, mark pendaftaran as Selesai
    if (rm.pendaftaranId) {
      handleUpdatePendaftaranStatus(rm.pendaftaranId, 'Selesai');
    }

    // If plan specifies Rawat Inap, auto create RawatInap record
    if (rm.plan.statusLanjutan === 'Rawat Inap') {
      const newInap: RawatInap = {
        id: 'inap-' + Date.now(),
        pasienId: rm.pasienId,
        noKandang: 'Kandang Kucing A-01',
        tanggalMasuk: new Date().toISOString().replace('T', ' ').slice(0, 16),
        dokterPenanggungJawabId: rm.dokterId,
        diagnosaInap: rm.assessment.diagnosaUtama,
        tarifPerHari: 100000,
        status: 'Aktif',
        monitoringLogs: [],
      };
      const updatedInap = [newInap, ...rawatInapList];
      setRawatInapList(updatedInap);
      storageService.saveRawatInapList(updatedInap);
    }
  };

  // Handlers for Rawat Inap
  const handleSaveRawatInap = (inap: RawatInap) => {
    const updated = [inap, ...rawatInapList];
    setRawatInapList(updated);
    storageService.saveRawatInapList(updated);
  };

  const handleAddLogMonitoring = (inapId: string, log: MonitoringLog) => {
    const updated = rawatInapList.map((inap) => {
      if (inap.id === inapId) {
        return {
          ...inap,
          monitoringLogs: [...inap.monitoringLogs, log]
        };
      }
      return inap;
    });
    setRawatInapList(updated);
    storageService.saveRawatInapList(updated);
  };

  const handleCheckoutInap = (inapId: string) => {
    const updated = rawatInapList.map((inap) => inap.id === inapId ? { ...inap, status: 'Selesai' as const, tanggalKeluar: new Date().toISOString().replace('T', ' ').slice(0, 16) } : inap);
    setRawatInapList(updated);
    storageService.saveRawatInapList(updated);
  };

  // Handlers for Janji Temu
  const handleSaveJanjiTemu = (jt: JanjiTemu) => {
    const updated = [jt, ...janjiTemuList];
    setJanjiTemuList(updated);
    storageService.saveJanjiTemuList(updated);
  };

  const handleUpdateJanjiTemuStatus = (id: string, status: any) => {
    const updated = janjiTemuList.map((jt) => jt.id === id ? { ...jt, status } : jt);
    setJanjiTemuList(updated);
    storageService.saveJanjiTemuList(updated);
  };

  // Handlers for Transaksi Kasir POS
  const handleSaveTransaksi = (trx: Transaksi) => {
    const updatedTrx = [trx, ...transaksiList];
    setTransaksiList(updatedTrx);
    storageService.saveTransaksiList(updatedTrx);

    // If payment for RM, update RM status to Lunas
    if (trx.rekamMedisId) {
      const updatedRM = rekamMedisList.map((rm) => rm.id === trx.rekamMedisId ? { ...rm, statusPembayaran: 'Lunas' as const } : rm);
      setRekamMedisList(updatedRM);
      storageService.saveRekamMedisList(updatedRM);
    }

    // Deduct inventory stock for items sold
    let currentBarang = [...barangList];
    trx.items.forEach((item) => {
      const bIdx = currentBarang.findIndex((b) => b.namaBarang.includes(item.namaItem) || b.id === item.id);
      if (bIdx !== -1) {
        currentBarang[bIdx] = {
          ...currentBarang[bIdx],
          stokCurrent: Math.max(0, currentBarang[bIdx].stokCurrent - item.jumlah),
        };
      }
    });
    setBarangList(currentBarang);
    storageService.saveBarangList(currentBarang);
  };

  const handleVoidTransaksi = (id: string, alasan: string, user: string) => {
    const updated = transaksiList.map((t) => t.id === id ? {
      ...t,
      status: 'Dibatalkan' as const,
      alasanPembatalan: alasan,
      dibatalkanOleh: user,
    } : t);
    setTransaksiList(updated);
    storageService.saveTransaksiList(updated);
  };

  // Handlers for Barang & Inventory
  const handleSaveBarang = (b: Barang) => {
    const exists = barangList.some((item) => item.id === b.id);
    const updated = exists
      ? barangList.map((item) => item.id === b.id ? b : item)
      : [b, ...barangList];
    setBarangList(updated);
    storageService.saveBarangList(updated);
  };

  const handleDeleteBarang = (id: string) => {
    const updated = barangList.filter((b) => b.id !== id);
    setBarangList(updated);
    storageService.saveBarangList(updated);
  };

  // Handlers for Master Data & RBAC
  const handleSaveUser = (u: User) => {
    const exists = userList.some((item) => item.id === u.id);
    const updated = exists
      ? userList.map((item) => item.id === u.id ? u : item)
      : [u, ...userList];
    setUserList(updated);
    storageService.saveUserList(updated);
  };

  const handleDeleteUser = (id: string) => {
    const updated = userList.filter((u) => u.id !== id);
    setUserList(updated);
    storageService.saveUserList(updated);
  };

  const handleSaveRBACConfig = (config: RBACConfig) => {
    setRbacConfig(config);
    storageService.saveRBACConfig(config);
  };

  const handleSaveWaConfig = (config: WhatsAppConfig) => {
    setWaConfig(config);
    storageService.saveWhatsAppConfig(config);
  };

  const handleSaveWaTemplates = (templates: WhatsAppTemplate[]) => {
    setWaTemplates(templates);
    storageService.saveWhatsAppTemplates(templates);
  };

  const handleAddWaLog = (logData: Omit<WhatsAppLog, 'id'>) => {
    const updated = storageService.addWhatsAppLog(logData);
    setWaLogs(updated);
  };

  const handleSaveDokter = (d: Dokter) => {
    const exists = dokterList.some((item) => item.id === d.id);
    const updated = exists
      ? dokterList.map((item) => item.id === d.id ? d : item)
      : [d, ...dokterList];
    setDokterList(updated);
    storageService.saveDokterList(updated);
  };

  const handleDeleteDokter = (id: string) => {
    const updated = dokterList.filter((d) => d.id !== id);
    setDokterList(updated);
    storageService.saveDokterList(updated);
  };

  const handleSaveTindakan = (t: Tindakan) => {
    const exists = tindakanList.some((item) => item.id === t.id);
    const updated = exists
      ? tindakanList.map((item) => item.id === t.id ? t : item)
      : [t, ...tindakanList];
    setTindakanList(updated);
    storageService.saveTindakanList(updated);
  };

  const handleDeleteTindakan = (id: string) => {
    const updated = tindakanList.filter((t) => t.id !== id);
    setTindakanList(updated);
    storageService.saveTindakanList(updated);
  };

  const handleSavePakan = (p: PakanHewan) => {
    const updated = [p, ...pakanList];
    setPakanList(updated);
    storageService.savePakanList(updated);
  };

  const handleSaveSpesies = (s: Spesies) => {
    const exists = spesiesList.some((item) => item.id === s.id);
    const updated = exists
      ? spesiesList.map((item) => item.id === s.id ? s : item)
      : [...spesiesList, s];
    setSpesiesList(updated);
    storageService.saveSpesiesList(updated);
  };

  const handleDeleteSpesies = (id: string) => {
    const updated = spesiesList.filter((s) => s.id !== id);
    setSpesiesList(updated);
    storageService.saveSpesiesList(updated);
  };

  // Settings & Klinik
  const handleSaveKlinik = (k: DataKlinik) => {
    setKlinik(k);
    storageService.saveKlinikData(k);
  };

  const handleSaveSettings = (s: AppSettings) => {
    setSettings(s);
    storageService.saveAppSettings(s);
  };

  if (!activeUser) {
    return (
      <LoginView
        userList={userList}
        klinik={klinik}
        onLogin={handleLogin}
        onUpdateUserList={(updated) => setUserList(updated)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800 antialiased selection:bg-indigo-500 selection:text-white pb-16 md:pb-0">
      
      {/* Top Navbar */}
      <Navbar
        activeUser={activeUser}
        userList={userList}
        klinik={klinik}
        barangList={barangList}
        onRoleChange={handleRoleChange}
        onLogout={handleLogout}
        onNavigateTab={(tab) => setActiveTab(tab)}
        onToggleMobileMenu={() => setIsMobileOpen((prev) => !prev)}
      />

      {/* Main Container Layout */}
      <div className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 py-6 flex flex-col md:flex-row gap-6">
        
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          userRole={activeUser.role}
          rbacConfig={rbacConfig}
          queueCount={queueCount}
          inpatientCount={inpatientCount}
          isMobileOpen={isMobileOpen}
          onCloseMobile={() => setIsMobileOpen(false)}
          onLogout={handleLogout}
        />

        {/* Content View Router with RBAC Guard */}
        <main className="flex-1 min-w-0">
          {(() => {
            const currentTabPerms = getModulePermissions(activeTab, activeUser.role, rbacConfig);

            if (!currentTabPerms.canView) {
              return (
                <AccessDeniedView
                  activeUser={activeUser}
                  tabId={activeTab}
                  onGoToDashboard={() => setActiveTab('dashboard')}
                />
              );
            }

            return (
              <>
                {activeTab === 'dashboard' && (
                  <DashboardView
                    pasienList={pasienList}
                    transaksiList={transaksiList}
                    rawatInapList={rawatInapList}
                    pendaftaranList={pendaftaranList}
                    barangList={barangList}
                    janjiTemuList={janjiTemuList}
                    onNavigateTab={setActiveTab}
                  />
                )}

                {activeTab === 'pendaftaran' && (
                  <PendaftaranView
                    pendaftaranList={pendaftaranList}
                    pasienList={pasienList}
                    dokterList={dokterList}
                    activeUser={activeUser}
                    onSavePendaftaran={handleSavePendaftaran}
                    onUpdateStatus={handleUpdatePendaftaranStatus}
                    onStartExamine={handleStartExamine}
                  />
                )}

                {activeTab === 'pasien' && (
                  <PasienView
                    pasienList={pasienList}
                    rekamMedisList={rekamMedisList}
                    dokterList={dokterList}
                    vaksinasiList={vaksinasiList}
                    spesiesList={spesiesList}
                    klinik={klinik}
                    permissions={currentTabPerms}
                    onSavePasien={handleSavePasien}
                    onDeletePasien={handleDeletePasien}
                  />
                )}

                {activeTab === 'rekam_medis' && (
                  <RekamMedisView
                    rekamMedisList={rekamMedisList}
                    pasienList={pasienList}
                    dokterList={dokterList}
                    barangList={barangList}
                    tindakanList={tindakanList}
                    pendaftaranList={pendaftaranList}
                    klinik={klinik}
                    activePendaftaran={activePendaftaranForSOAP}
                    onSaveRekamMedis={handleSaveRekamMedis}
                    onClearActivePendaftaran={() => setActivePendaftaranForSOAP(null)}
                  />
                )}

                {activeTab === 'rawat_jalan' && (
                  <RawatJalanView
                    rekamMedisList={rekamMedisList}
                    pasienList={pasienList}
                    dokterList={dokterList}
                    barangList={barangList}
                    tindakanList={tindakanList}
                    pendaftaranList={pendaftaranList}
                    klinik={klinik}
                    transaksiList={transaksiList}
                    onNavigateToSOAP={(pendaftaran) => {
                      if (pendaftaran) setActivePendaftaranForSOAP(pendaftaran);
                      setActiveTab('rekam_medis');
                    }}
                    onNavigateToKasir={(rmId) => {
                      setActiveTab('kasir');
                    }}
                    onSaveRekamMedis={handleSaveRekamMedis}
                  />
                )}

                {activeTab === 'rawat_inap' && (
                  <RawatInapView
                    rawatInapList={rawatInapList}
                    pasienList={pasienList}
                    dokterList={dokterList}
                    klinik={klinik}
                    rekamMedisList={rekamMedisList}
                    transaksiList={transaksiList}
                    onSaveRawatInap={handleSaveRawatInap}
                    onAddLogMonitoring={handleAddLogMonitoring}
                    onCheckoutInap={handleCheckoutInap}
                  />
                )}

                {activeTab === 'janji_temu' && (
                  <JanjiTemuView
                    janjiTemuList={janjiTemuList}
                    pasienList={pasienList}
                    dokterList={dokterList}
                    klinik={klinik}
                    onSaveJanjiTemu={handleSaveJanjiTemu}
                    onUpdateStatus={handleUpdateJanjiTemuStatus}
                  />
                )}

                {activeTab === 'kasir' && (
                  <KasirView
                    transaksiList={transaksiList}
                    rekamMedisList={rekamMedisList}
                    rawatInapList={rawatInapList}
                    pasienList={pasienList}
                    klinik={klinik}
                    settings={settings}
                    activeUser={activeUser}
                    onSaveTransaksi={handleSaveTransaksi}
                    onVoidTransaksi={handleVoidTransaksi}
                  />
                )}

                {(activeTab === 'penjualan' || activeTab === 'penjualan_direct') && (
                  <PenjualanDirectView
                    barangList={barangList}
                    klinik={klinik}
                    settings={settings}
                    activeUser={activeUser}
                    onSaveTransaksi={handleSaveTransaksi}
                  />
                )}

                {activeTab === 'inventory' && (
                  <InventoryView
                    barangList={barangList}
                    permissions={currentTabPerms}
                    onSaveBarang={handleSaveBarang}
                    onDeleteBarang={handleDeleteBarang}
                  />
                )}

                {activeTab === 'pembelian' && (
                  <PembelianView
                    pembelianList={pembelianList}
                    supplierList={supplierList}
                    barangList={barangList}
                    onSavePembelian={(po) => {
                      const updated = [po, ...pembelianList];
                      setPembelianList(updated);
                      storageService.savePembelianList(updated);
                    }}
                  />
                )}

                {(activeTab === 'master' || activeTab === 'master_data') && (
                  <MasterDataView
                    userList={userList}
                    dokterList={dokterList}
                    tindakanList={tindakanList}
                    pakanList={pakanList}
                    spesiesList={spesiesList}
                    activeUser={activeUser}
                    onSaveUser={handleSaveUser}
                    onSaveDokter={handleSaveDokter}
                    onDeleteDokter={handleDeleteDokter}
                    onSaveTindakan={handleSaveTindakan}
                    onDeleteTindakan={handleDeleteTindakan}
                    onSavePakan={handleSavePakan}
                    onSaveSpesies={handleSaveSpesies}
                    onDeleteSpesies={handleDeleteSpesies}
                  />
                )}

                {activeTab === 'laporan' && (
                  <LaporanKeuanganView
                    transaksiList={transaksiList}
                    onNavigateToLaba={() => setActiveTab('laporan_laba')}
                  />
                )}

                {activeTab === 'laporan_laba' && (
                  <LaporanLabaPenjualanView
                    transaksiList={transaksiList}
                    barangList={barangList}
                    pakanList={pakanList}
                  />
                )}

                {activeTab === 'laporan_tren_penyakit' && (
                  <LaporanTrenPenyakitView
                    rekamMedisList={rekamMedisList}
                    pasienList={pasienList}
                    dokterList={dokterList}
                  />
                )}

                {activeTab === 'hak_akses' && (
                  <HakAksesView
                    userList={userList}
                    activeUser={activeUser}
                    rbacConfig={rbacConfig}
                    onSaveRBACConfig={handleSaveRBACConfig}
                    onSaveUser={handleSaveUser}
                    onDeleteUser={handleDeleteUser}
                    onSwitchUserContext={(u) => {
                      setActiveUser(u);
                      storageService.setActiveUser(u);
                    }}
                  />
                )}

                {activeTab === 'whatsapp' && (
                  <WhatsAppIntegrationView
                    pasienList={pasienList}
                    dokterList={dokterList}
                    janjiTemuList={janjiTemuList}
                    klinik={klinik}
                    waConfig={waConfig}
                    onSaveWaConfig={handleSaveWaConfig}
                    waTemplates={waTemplates}
                    onSaveWaTemplates={handleSaveWaTemplates}
                    waLogs={waLogs}
                    onAddWaLog={handleAddWaLog}
                  />
                )}

                {activeTab === 'pengaturan' && (
                  <PengaturanView
                    klinik={klinik}
                    settings={settings}
                    onSaveKlinik={handleSaveKlinik}
                    onSaveSettings={handleSaveSettings}
                    onReloadAllData={loadAllData}
                  />
                )}
              </>
            );
          })()}
        </main>
      </div>

      {/* Mobile Sticky Bottom Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 z-40 px-2 py-1.5 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'dashboard' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">📊</span>
          <span>Dashboard</span>
        </button>

        <button
          onClick={() => setActiveTab('pendaftaran')}
          className={`relative flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'pendaftaran' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">📋</span>
          <span>Antrian</span>
          {queueCount > 0 && (
            <span className="absolute -top-1 right-1 bg-indigo-500 text-white text-[9px] font-bold px-1.5 rounded-full">
              {queueCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('rekam_medis')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'rekam_medis' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">🩺</span>
          <span>SOAP</span>
        </button>

        <button
          onClick={() => setActiveTab('kasir')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            activeTab === 'kasir' ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">💳</span>
          <span>Kasir</span>
        </button>

        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-semibold transition-colors ${
            isMobileOpen ? 'text-indigo-400 font-bold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">☰</span>
          <span>Menu</span>
        </button>
      </div>

    </div>
  );
}

export default App;
