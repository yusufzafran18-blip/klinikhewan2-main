// Firebase Firestore has been completely disconnected and removed as requested.
// Authentication config placeholder
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);

export const checkFirebaseConnection = async () => {
  return {
    success: false,
    message: 'Firestore dinonaktifkan (Database telah beralih ke SQL / MySQL Database).',
  };
};
