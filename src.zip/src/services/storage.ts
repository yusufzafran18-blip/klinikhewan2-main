import {
  User, Dokter, Pasien, Barang, Tindakan, Pakan, Pendaftaran, RekamMedis,
  RawatInap, JanjiTemu, RiwayatVaksinasi, Transaksi, PembelianBarang,
  FeedbackOwner, DataKlinik, AppSettings, Supplier, Spesies, RBACConfig, ModulePermissionItem,
  WhatsAppConfig, WhatsAppTemplate, WhatsAppLog
} from '../types';
import {
  saveClinicDataToSql,
  fetchClinicDataFromSql,
  checkSqlStatus,
  SqlSyncPayload,
} from './sqlApi';

const STORAGE_KEYS = {
  USERS: 'vetcare_users',
  DOKTER: 'vetcare_dokter',
  PASIEN: 'vetcare_pasien',
  BARANG: 'vetcare_barang',
  TINDAKAN: 'vetcare_tindakan',
  PAKAN: 'vetcare_pakan',
  SPESIES: 'vetcare_spesies',
  PENDAFTARAN: 'vetcare_pendaftaran',
  REKAM_MEDIS: 'vetcare_rekam_medis',
  RAWAT_INAP: 'vetcare_rawat_inap',
  JANJI_TEMU: 'vetcare_janji_temu',
  VAKSINASI: 'vetcare_vaksinasi',
  TRANSAKSI: 'vetcare_transaksi',
  PEMBELIAN: 'vetcare_pembelian',
  SUPPLIER: 'vetcare_supplier',
  FEEDBACK: 'vetcare_feedback',
  KLINIK: 'vetcare_klinik',
  SETTINGS: 'vetcare_settings',
  ACTIVE_USER: 'vetcare_active_user',
  RBAC: 'vetcare_rbac_config',
  WA_CONFIG: 'vetcare_wa_config',
  WA_TEMPLATES: 'vetcare_wa_templates',
  WA_LOGS: 'vetcare_wa_logs',
  SEED_VERSION: 'vetcare_seed_version_2',
};

const CURRENT_SEED_VERSION = 'v2.5_comprehensive_data';

// ==========================================
// COMPREHENSIVE INITIAL MOCK DATA
// ==========================================

const INITIAL_SPESIES: Spesies[] = [
  { id: 'sps-1', kodeSpesies: 'SPS-001', namaSpesies: 'Kucing', keterangan: 'Felis catus - Kucing domestik & ras' },
  { id: 'sps-2', kodeSpesies: 'SPS-002', namaSpesies: 'Anjing', keterangan: 'Canis lupus familiaris - Berbagai ras anjing' },
  { id: 'sps-3', kodeSpesies: 'SPS-003', namaSpesies: 'Kelinci', keterangan: 'Oryctolagus cuniculus' },
  { id: 'sps-4', kodeSpesies: 'SPS-004', namaSpesies: 'Burung', keterangan: 'Aves - Lovebird, Parakeet, Kakakatua, dll' },
  { id: 'sps-5', kodeSpesies: 'SPS-005', namaSpesies: 'Reptil', keterangan: 'Iguana, Ular, Kura-kura, Gecko' },
  { id: 'sps-6', kodeSpesies: 'SPS-006', namaSpesies: 'Hamster', keterangan: 'Cricetinae - Roborovski, Syrian, Winter White' },
  { id: 'sps-7', kodeSpesies: 'SPS-007', namaSpesies: 'Sugar Glider', keterangan: 'Petaurus breviceps' },
  { id: 'sps-8', kodeSpesies: 'SPS-008', namaSpesies: 'Musang & Ferret', keterangan: 'Mustelidae & Viverridae' },
  { id: 'sps-9', kodeSpesies: 'SPS-009', namaSpesies: 'Ikan Hias', keterangan: 'Koi, Koki, Betta, Discus' },
  { id: 'sps-10', kodeSpesies: 'SPS-010', namaSpesies: 'Lainnya', keterangan: 'Spesies / hewan eksotis lainnya' },
];

const INITIAL_USERS: User[] = [
  { id: 'usr-1', username: 'superadmin', nama: 'Super Admin VetCare', email: 'superadmin@vetcare.id', role: 'super_admin', noHp: '081234567890', aktif: true, password: 'admin123' },
  { id: 'usr-2', username: 'admin', nama: 'Admin Operational', email: 'admin@vetcare.id', role: 'admin', noHp: '081234567891', aktif: true, password: 'admin123' },
  { id: 'usr-3', username: 'staf', nama: 'Rina Staf Receptionist', email: 'staf@vetcare.id', role: 'staf', noHp: '081234567892', aktif: true, password: 'admin123' },
  { id: 'usr-4', username: 'drh_andi', nama: 'drh. Andi Pratama, M.Si', email: 'drh.andi@vetcare.id', role: 'dokter', noHp: '081234567893', aktif: true, password: 'admin123' },
  { id: 'usr-5', username: 'drh_siska', nama: 'drh. Siska Amanda, Sp.K', email: 'drh.siska@vetcare.id', role: 'dokter', noHp: '081234567894', aktif: true, password: 'admin123' },
  { id: 'usr-6', username: 'drh_budi', nama: 'drh. Budi Setiawan, M.Vet', email: 'drh.budi@vetcare.id', role: 'dokter', noHp: '081234567895', aktif: true, password: 'admin123' },
];

const INITIAL_DOKTER: Dokter[] = [
  {
    id: 'dok-1',
    sip: 'SIP.503/449/DRH/2024',
    nama: 'drh. Andi Pratama, M.Si',
    spesialisasi: 'Bedah Hewan Kecil & Interna',
    noHp: '081234567893',
    email: 'drh.andi@vetcare.id',
    jadwal: 'Senin - Jumat (08:00 - 16:00)',
    aktif: true,
    fotoUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'dok-2',
    sip: 'SIP.503/112/DRH/2025',
    nama: 'drh. Siska Amanda, Sp.K',
    spesialisasi: 'Dermatologi & Eksotis Pet',
    noHp: '081234567894',
    email: 'drh.siska@vetcare.id',
    jadwal: 'Selasa - Sabtu (10:00 - 18:00)',
    aktif: true,
    fotoUrl: 'https://images.unsplash.com/photo-1594824813566-88855ce7890f?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'dok-3',
    sip: 'SIP.503/881/DRH/2025',
    nama: 'drh. Budi Setiawan, M.Vet',
    spesialisasi: 'Orthopedi & Radiologi Veteriner',
    noHp: '081234567895',
    email: 'drh.budi@vetcare.id',
    jadwal: 'Rabu - Minggu (12:00 - 20:00)',
    aktif: true,
    fotoUrl: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=300&auto=format&fit=crop&q=80'
  },
  {
    id: 'dok-4',
    sip: 'SIP.503/332/DRH/2026',
    nama: 'drh. Maya Indah, M.Sc',
    spesialisasi: 'Penyakit Dalam & Odontologi',
    noHp: '081234567896',
    email: 'drh.maya@vetcare.id',
    jadwal: 'Senin - Kamis (13:00 - 21:00)',
    aktif: true,
    fotoUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&auto=format&fit=crop&q=80'
  }
];

const INITIAL_PASIEN: Pasien[] = [
  {
    id: 'pas-1',
    kodePasien: 'PAS-2026-001',
    namaHewan: 'Mochi',
    jenisHewan: 'Kucing',
    ras: 'Persia Medium',
    jenisKelamin: 'Jantan Kastrasi',
    tanggalLahir: '2023-05-12',
    umurFormat: '3 Tahun 2 Bulan',
    warna: 'Putih Abu-abu',
    noMicrochip: 'MC-98200192',
    namaOwner: 'Budi Santoso',
    noHpOwner: '081299887766',
    alamatOwner: 'Jl. Pemuda No. 45, Jember',
    emailOwner: 'budi.santoso@gmail.com',
    fotoUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Sensitif terhadap pakan berprotein tinggi non-grain free. Alergi Amoxicillin injeksi.',
    createdAt: '2026-01-10'
  },
  {
    id: 'pas-2',
    kodePasien: 'PAS-2026-002',
    namaHewan: 'Milo',
    jenisHewan: 'Anjing',
    ras: 'Golden Retriever',
    jenisKelamin: 'Jantan',
    tanggalLahir: '2022-08-20',
    umurFormat: '3 Tahun 11 Bulan',
    warna: 'Coklat Keemasan',
    noMicrochip: 'MC-77390111',
    namaOwner: 'Siti Rahmawati',
    noHpOwner: '085711223344',
    alamatOwner: 'Jl. Kalimantan No. 12, Jember',
    emailOwner: 'siti.rahma@yahoo.com',
    fotoUrl: 'https://images.unsplash.com/photo-1552053831-71594a27632d?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Alergi ringan pada kulit jika lembap. Sangat jinak.',
    createdAt: '2026-02-01'
  },
  {
    id: 'pas-3',
    kodePasien: 'PAS-2026-003',
    namaHewan: 'Oreo',
    jenisHewan: 'Kucing',
    ras: 'Domestic Short Hair',
    jenisKelamin: 'Betina Steril',
    tanggalLahir: '2024-01-15',
    umurFormat: '2 Tahun 6 Bulan',
    warna: 'Hitam Putih (Tuxedo)',
    namaOwner: 'Dewi Lestari',
    noHpOwner: '081388990011',
    alamatOwner: 'Jl. Mastrip Blok B-3, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Rutin grooming jamur per bulan',
    createdAt: '2026-03-15'
  },
  {
    id: 'pas-4',
    kodePasien: 'PAS-2026-004',
    namaHewan: 'Clover',
    jenisHewan: 'Kelinci',
    ras: 'Holland Lop',
    jenisKelamin: 'Betina',
    tanggalLahir: '2025-02-10',
    umurFormat: '1 Tahun 5 Bulan',
    warna: 'Oranye Cream',
    namaOwner: 'Rian Kurniawan',
    noHpOwner: '082144556677',
    alamatOwner: 'Jl. Gajah Mada No. 88, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Sensitif pencernaan, butuh pakan serat tinggi Oxbow',
    createdAt: '2026-04-02'
  },
  {
    id: 'pas-5',
    kodePasien: 'PAS-2026-005',
    namaHewan: 'Bella',
    jenisHewan: 'Kucing',
    ras: 'Maine Coon',
    jenisKelamin: 'Betina',
    tanggalLahir: '2023-11-05',
    umurFormat: '2 Tahun 8 Bulan',
    warna: 'Tabby Coklat',
    noMicrochip: 'MC-88102931',
    namaOwner: 'dr. Hendra Wijaya',
    noHpOwner: '081233445566',
    alamatOwner: 'Perumahan Grand Puri B-12, Jember',
    emailOwner: 'hendra.w@clinic.com',
    fotoUrl: 'https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Riwayat gingivitis ringan tahun lalu',
    createdAt: '2026-04-18'
  },
  {
    id: 'pas-6',
    kodePasien: 'PAS-2026-006',
    namaHewan: 'Max',
    jenisHewan: 'Anjing',
    ras: 'Shih Tzu',
    jenisKelamin: 'Jantan',
    tanggalLahir: '2024-03-22',
    umurFormat: '2 Tahun 4 Bulan',
    warna: 'Putih Coklat',
    namaOwner: 'Agnes Monica',
    noHpOwner: '085299001122',
    alamatOwner: 'Jl. Riau No. 09, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Mata gampang berair, butuh pembersihan mata rutin',
    createdAt: '2026-05-10'
  },
  {
    id: 'pas-7',
    kodePasien: 'PAS-2026-007',
    namaHewan: 'Rio',
    jenisHewan: 'Burung',
    ras: 'Lovebird Parblue',
    jenisKelamin: 'Jantan',
    tanggalLahir: '2025-06-01',
    umurFormat: '1 Tahun 1 Bulan',
    warna: 'Biru Toska Kuning',
    namaOwner: 'Ahmad Fauzi',
    noHpOwner: '081988776655',
    alamatOwner: 'Jl. Jawa No. 102, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1522858547137-f1dcec554f55?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Sayap kanan pernah terkilir ringan',
    createdAt: '2026-05-28'
  },
  {
    id: 'pas-8',
    kodePasien: 'PAS-2026-008',
    namaHewan: 'Spike',
    jenisHewan: 'Reptil',
    ras: 'Iguana Hijau',
    jenisKelamin: 'Jantan',
    tanggalLahir: '2023-01-10',
    umurFormat: '3 Tahun 6 Bulan',
    warna: 'Hijau Cerah',
    namaOwner: 'Kevin Sanjaya',
    noHpOwner: '087812345678',
    alamatOwner: 'Jl. Hayam Wuruk No. 54, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Butuh kalsium & UVB rutin',
    createdAt: '2026-06-01'
  },
  {
    id: 'pas-9',
    kodePasien: 'PAS-2026-009',
    namaHewan: 'Luna',
    jenisHewan: 'Kucing',
    ras: 'British Shorthair',
    jenisKelamin: 'Betina Steril',
    tanggalLahir: '2024-05-18',
    umurFormat: '2 Tahun 2 Bulan',
    warna: 'Blue Grey',
    noMicrochip: 'MC-66100922',
    namaOwner: 'Maya Putri',
    noHpOwner: '081211223344',
    alamatOwner: 'Jl. Trunojoyo No. 77, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1513245543132-31f507417b26?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Paling tenang saat diperiksa',
    createdAt: '2026-06-15'
  },
  {
    id: 'pas-10',
    kodePasien: 'PAS-2026-010',
    namaHewan: 'Rocky',
    jenisHewan: 'Anjing',
    ras: 'Beagle',
    jenisKelamin: 'Jantan',
    tanggalLahir: '2023-09-09',
    umurFormat: '2 Tahun 10 Bulan',
    warna: 'Tricolor (Hitam Putih Coklat)',
    namaOwner: 'Doni Prasetyo',
    noHpOwner: '085677889900',
    alamatOwner: 'Jl. Teuku Umar No. 18, Jember',
    fotoUrl: 'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=400&auto=format&fit=crop&q=80',
    catatanKhusus: 'Aktif sekali, suka makan berlebihan',
    createdAt: '2026-07-01'
  }
];

const INITIAL_BARANG: Barang[] = [
  { id: 'brg-1', kodeBarang: 'OBT-001', namaBarang: 'Amoxicillin Syrup 60ml', kategori: 'Obat', satuan: 'Botol', hargaBeli: 25000, hargaJual: 45000, stokCurrent: 28, stokMinimum: 10, expiredDate: '2027-12-31', lokasiRak: 'Rak A-1' },
  { id: 'brg-2', kodeBarang: 'OBT-002', namaBarang: 'Ivermectin Injection 10ml', kategori: 'Obat', satuan: 'Ampul', hargaBeli: 60000, hargaJual: 95000, stokCurrent: 8, stokMinimum: 5, expiredDate: '2027-06-30', lokasiRak: 'Kulkas Medis B' },
  { id: 'brg-3', kodeBarang: 'OBT-003', namaBarang: 'Salep Mata Terramycin 3.5g', kategori: 'Obat', satuan: 'Tablet', hargaBeli: 18000, hargaJual: 35000, stokCurrent: 15, stokMinimum: 8, expiredDate: '2028-01-15', lokasiRak: 'Rak A-2' },
  { id: 'brg-4', kodeBarang: 'VAK-001', namaBarang: 'Vaksin Rabies Defensor 3', kategori: 'Obat', satuan: 'Ampul', hargaBeli: 75000, hargaJual: 150000, stokCurrent: 18, stokMinimum: 10, expiredDate: '2027-10-20', lokasiRak: 'Kulkas Vaksin A' },
  { id: 'brg-5', kodeBarang: 'VAK-002', namaBarang: 'Vaksin Felocell 4 (Cat)', kategori: 'Obat', satuan: 'Ampul', hargaBeli: 110000, hargaJual: 220000, stokCurrent: 12, stokMinimum: 5, expiredDate: '2027-09-15', lokasiRak: 'Kulkas Vaksin A' },
  { id: 'brg-6', kodeBarang: 'ALK-001', namaBarang: 'Cairan Infus Ringer Lactate 500ml', kategori: 'Alkes', satuan: 'Botol', hargaBeli: 16000, hargaJual: 35000, stokCurrent: 45, stokMinimum: 15, expiredDate: '2028-05-30', lokasiRak: 'Gudang Alkes B' },
  { id: 'brg-7', kodeBarang: 'ALK-002', namaBarang: 'Infusion Set Vet Micro Terumo', kategori: 'Alkes', satuan: 'Pcs', hargaBeli: 12000, hargaJual: 25000, stokCurrent: 50, stokMinimum: 20, expiredDate: '2029-01-01', lokasiRak: 'Gudang Alkes B' },
  { id: 'brg-8', kodeBarang: 'PAK-001', namaBarang: 'Royal Canin Recovery Wet 195g', kategori: 'Pakan', satuan: 'Pcs', hargaBeli: 38000, hargaJual: 55000, stokCurrent: 24, stokMinimum: 10, expiredDate: '2027-11-10', lokasiRak: 'Rak Petshop C' },
  { id: 'brg-9', kodeBarang: 'PAK-002', namaBarang: 'Pro Plan Cat Urinary Optirenal 1.5kg', kategori: 'Pakan', satuan: 'Pcs', hargaBeli: 185000, hargaJual: 240000, stokCurrent: 10, stokMinimum: 5, expiredDate: '2027-08-22', lokasiRak: 'Rak Petshop C' },
  { id: 'brg-10', kodeBarang: 'OBT-004', namaBarang: 'Doxycycline 100mg Tab', kategori: 'Obat', satuan: 'Tablet', hargaBeli: 2000, hargaJual: 5000, stokCurrent: 120, stokMinimum: 30, expiredDate: '2028-03-10', lokasiRak: 'Rak A-3' },
  { id: 'brg-11', kodeBarang: 'VAK-003', namaBarang: 'Vaksin Vanguard Plus 5/L (Dog)', kategori: 'Obat', satuan: 'Ampul', hargaBeli: 130000, hargaJual: 250000, stokCurrent: 14, stokMinimum: 5, expiredDate: '2027-11-28', lokasiRak: 'Kulkas Vaksin A' },
  { id: 'brg-12', kodeBarang: 'OBT-005', namaBarang: 'Bravecto Chewable Dog 10-20kg', kategori: 'Obat', satuan: 'Tablet', hargaBeli: 280000, hargaJual: 360000, stokCurrent: 9, stokMinimum: 3, expiredDate: '2028-04-12', lokasiRak: 'Rak B-1' },
  { id: 'brg-13', kodeBarang: 'OBT-006', namaBarang: 'Revolution Spot-On Cat 2.5-7.5kg', kategori: 'Obat', satuan: 'Box', hargaBeli: 115000, hargaJual: 165000, stokCurrent: 16, stokMinimum: 5, expiredDate: '2028-06-30', lokasiRak: 'Rak B-1' },
  { id: 'brg-14', kodeBarang: 'ALK-003', namaBarang: 'Spuit 3ml Terumo (Box 100)', kategori: 'Alkes', satuan: 'Box', hargaBeli: 85000, hargaJual: 120000, stokCurrent: 7, stokMinimum: 3, expiredDate: '2029-03-15', lokasiRak: 'Gudang Alkes A' },
  { id: 'brg-15', kodeBarang: 'ALK-004', namaBarang: 'Catheter IV 24G Terumo', kategori: 'Alkes', satuan: 'Pcs', hargaBeli: 15000, hargaJual: 30000, stokCurrent: 40, stokMinimum: 10, expiredDate: '2029-02-20', lokasiRak: 'Gudang Alkes A' },
  { id: 'brg-16', kodeBarang: 'ALK-005', namaBarang: 'Underpad Perlak Medis 60x90cm (Pack 10)', kategori: 'Alkes', satuan: 'Box', hargaBeli: 35000, hargaJual: 55000, stokCurrent: 25, stokMinimum: 8, expiredDate: '2030-01-01', lokasiRak: 'Gudang Alkes C' },
  { id: 'brg-17', kodeBarang: 'OBT-007', namaBarang: 'Ondansetron 2mg/ml Injection', kategori: 'Obat', satuan: 'Ampul', hargaBeli: 12000, hargaJual: 25000, stokCurrent: 35, stokMinimum: 10, expiredDate: '2028-08-10', lokasiRak: 'Rak A-1' },
  { id: 'brg-18', kodeBarang: 'OBT-008', namaBarang: 'Meloxicam 1.5mg/ml Oral Suspension 10ml', kategori: 'Obat', satuan: 'Botol', hargaBeli: 65000, hargaJual: 110000, stokCurrent: 11, stokMinimum: 4, expiredDate: '2027-12-01', lokasiRak: 'Rak A-2' }
];

const INITIAL_TINDAKAN: Tindakan[] = [
  { id: 'tdk-1', kodeTindakan: 'TND-001', namaTindakan: 'Pemeriksaan & Konsultasi Dokter', kategori: 'Pemeriksaan', tarif: 75000, komisiDokter: 25000 },
  { id: 'tdk-2', kodeTindakan: 'TND-002', namaTindakan: 'Vaksinasi Kucing (Felocell 4)', kategori: 'Vaksinasi', tarif: 220000, komisiDokter: 50000 },
  { id: 'tdk-3', kodeTindakan: 'TND-003', namaTindakan: 'Vaksinasi Rabies Defensor', kategori: 'Vaksinasi', tarif: 150000, komisiDokter: 35000 },
  { id: 'tdk-4', kodeTindakan: 'TND-004', namaTindakan: 'Steril Jantan Kucing (Kastrasi)', kategori: 'Bedah/Operasi', tarif: 450000, komisiDokter: 150000 },
  { id: 'tdk-5', kodeTindakan: 'TND-005', namaTindakan: 'Steril Betina Kucing (OH)', kategori: 'Bedah/Operasi', tarif: 750000, komisiDokter: 250000 },
  { id: 'tdk-6', kodeTindakan: 'TND-006', namaTindakan: 'Rontgen Thorax / Abdomen (1 View)', kategori: 'Lab/Radiologi', tarif: 250000, komisiDokter: 60000 },
  { id: 'tdk-7', kodeTindakan: 'TND-007', namaTindakan: 'Pemeriksaan Darah Lengkap (Hematologi)', kategori: 'Lab/Radiologi', tarif: 200000, komisiDokter: 40000 },
  { id: 'tdk-8', kodeTindakan: 'TND-008', namaTindakan: 'Grooming Medis Jamur/Kutu', kategori: 'Grooming', tarif: 110000, komisiDokter: 20000 },
  { id: 'tdk-9', kodeTindakan: 'TND-009', namaTindakan: 'Perawatan Rawat Inap Per Hari', kategori: 'Rawat Inap', tarif: 100000, komisiDokter: 25000 },
  { id: 'tdk-10', kodeTindakan: 'TND-010', namaTindakan: 'Scaling Gigi & Cleaning Ultrasound', kategori: 'Tindakan Medis', tarif: 350000, komisiDokter: 100000 },
  { id: 'tdk-11', kodeTindakan: 'TND-011', namaTindakan: 'Pemeriksaan USG Abdomen', kategori: 'Lab/Radiologi', tarif: 300000, komisiDokter: 80000 },
  { id: 'tdk-12', kodeTindakan: 'TND-012', namaTindakan: 'Test Kit Rapid Parvo / Panleukopenia', kategori: 'Laboratorium', tarif: 180000, komisiDokter: 40000 },
  { id: 'tdk-13', kodeTindakan: 'TND-013', namaTindakan: 'Pemasangan IV Line & Infus Therapy', kategori: 'Tindakan Medis', tarif: 75000, komisiDokter: 20000 },
  { id: 'tdk-14', kodeTindakan: 'TND-014', namaTindakan: 'Vaksinasi Anjing (Vanguard 5/L)', kategori: 'Vaksinasi', tarif: 250000, komisiDokter: 60000 }
];

const INITIAL_PAKAN: Pakan[] = [
  { id: 'pkn-1', kodePakan: 'PKN-01', namaPakan: 'Royal Canin Gastrointestinal Wet', merk: 'Royal Canin', kategoriUsia: 'Adult', dosisPerKgBb: '35g per kg BB', hargaJual: 58000, stok: 30, satuan: 'Sachet' },
  { id: 'pkn-2', kodePakan: 'PKN-02', namaPakan: 'Hills Science Diet A/D Critical Care', merk: 'Hills', kategoriUsia: 'Veterinary Diet', dosisPerKgBb: '40g per kg BB', hargaJual: 72000, stok: 20, satuan: 'Sachet' },
  { id: 'pkn-3', kodePakan: 'PKN-03', namaPakan: 'Royal Canin Urinarium S/O Wet', merk: 'Royal Canin', kategoriUsia: 'Veterinary Diet', dosisPerKgBb: '40g per kg BB', hargaJual: 62000, stok: 18, satuan: 'Sachet' },
  { id: 'pkn-4', kodePakan: 'PKN-04', namaPakan: 'Pro Plan Veterinary Diets CN', merk: 'Purina Pro Plan', kategoriUsia: 'Veterinary Diet', dosisPerKgBb: '30g per kg BB', hargaJual: 68000, stok: 15, satuan: 'Sachet' },
  { id: 'pkn-5', kodePakan: 'PKN-05', namaPakan: 'Oxbow Critical Care Herbivore 141g', merk: 'Oxbow', kategoriUsia: 'Adult', dosisPerKgBb: '15g per kg BB (Kelinci)', hargaJual: 145000, stok: 12, satuan: 'Pcs' },
  { id: 'pkn-6', kodePakan: 'PKN-06', namaPakan: 'Royal Canin Mother & Babycat 400g', merk: 'Royal Canin', kategoriUsia: 'Kitten/Puppy', dosisPerKgBb: '50g per kg BB', hargaJual: 78000, stok: 25, satuan: 'Pcs' }
];

const INITIAL_PENDAFTARAN: Pendaftaran[] = [
  {
    id: 'pdf-1',
    noAntrian: 'A-001',
    pasienId: 'pas-1',
    dokterId: 'dok-1',
    tanggal: new Date().toISOString().split('T')[0],
    waktu: '09:00',
    keluhanUtama: 'Kucing lemas, nafsu makan turun sejak kemarin, agak demam',
    layananDipilih: 'Pemeriksaan Umum & Rawat Inap',
    status: 'Diperiksa',
    petugasId: 'usr-3'
  },
  {
    id: 'pdf-2',
    noAntrian: 'A-002',
    pasienId: 'pas-2',
    dokterId: 'dok-2',
    tanggal: new Date().toISOString().split('T')[0],
    waktu: '10:15',
    keluhanUtama: 'Gatal-gatal di telinga dan garuk terus, kemerahan di daun telinga',
    layananDipilih: 'Pemeriksaan Kulit & Telinga',
    status: 'Antri',
    petugasId: 'usr-3'
  },
  {
    id: 'pdf-3',
    noAntrian: 'A-003',
    pasienId: 'pas-3',
    dokterId: 'dok-1',
    tanggal: new Date().toISOString().split('T')[0],
    waktu: '11:00',
    keluhanUtama: 'Jadwal Kontrol Paska Grooming Medis Jamur',
    layananDipilih: 'Kontrol / Routine Checkup',
    status: 'Selesai',
    petugasId: 'usr-3'
  },
  {
    id: 'pdf-4',
    noAntrian: 'A-004',
    pasienId: 'pas-5',
    dokterId: 'dok-4',
    tanggal: new Date().toISOString().split('T')[0],
    waktu: '13:30',
    keluhanUtama: 'Bau mulut dan karang gigi menumpuk, sesekali sulit mengunyah kibble',
    layananDipilih: 'Dental Scaling ultrasound',
    status: 'Diperiksa',
    petugasId: 'usr-3'
  },
  {
    id: 'pdf-5',
    noAntrian: 'A-005',
    pasienId: 'pas-6',
    dokterId: 'dok-3',
    tanggal: new Date().toISOString().split('T')[0],
    waktu: '14:45',
    keluhanUtama: 'Pincang kaki kiri belakang setelah melompat sofa',
    layananDipilih: 'Pemeriksaan Orthopedi & Rontgen',
    status: 'Antri',
    petugasId: 'usr-3'
  },
  {
    id: 'pdf-6',
    noAntrian: 'A-006',
    pasienId: 'pas-9',
    dokterId: 'dok-2',
    tanggal: new Date().toISOString().split('T')[0],
    waktu: '15:30',
    keluhanUtama: 'Vaksinasi Felocell 4 Booster Tahunan',
    layananDipilih: 'Vaksinasi Kucing',
    status: 'Selesai',
    petugasId: 'usr-3'
  }
];

const INITIAL_REKAM_MEDIS: RekamMedis[] = [
  {
    id: 'rm-1',
    noRM: 'RM-2026-0001',
    pendaftaranId: 'pdf-1',
    pasienId: 'pas-1',
    dokterId: 'dok-1',
    tanggal: '2026-07-28',
    subjective: {
      keluhan: 'Lemas dan tidak mau makan 2 hari',
      anamnesa: 'Pemilik menyebutkan Mochi sempat main di kebun lalu muntah 1x cairan bening, turgor lambat.',
      makanMinum: 'Menurun',
      durasiSakit: '2 Hari'
    },
    objective: {
      beratBadan: 3.8,
      suhu: 39.2,
      frekuensiNapas: 28,
      detakJantung: 130,
      crt: '< 2 Detik',
      dehidrasi: 'Mulai Dehidrasi (5%)',
      pemeriksaanFisik: 'Mukosa agak pucat, Turgor kulit sedikit lambat kembali, mukosa mulut kering, palpasi abdomen agak tegang.'
    },
    assessment: {
      diagnosaUtama: 'Gastritis Akut + Suspek Flu Kucing Ringan',
      diagnosaBanding: 'Panleukopenia, Foreign Body Obstruction'
    },
    plan: {
      tindakanList: [
        { tindakanId: 'tdk-1', namaTindakan: 'Pemeriksaan & Konsultasi Dokter', tarif: 75000 },
        { tindakanId: 'tdk-13', namaTindakan: 'Pemasangan IV Line & Infus Therapy', tarif: 75000 },
        { tindakanId: 'tdk-9', namaTindakan: 'Perawatan Rawat Inap Per Hari', tarif: 100000 }
      ],
      resepList: [
        { barangId: 'brg-1', namaBarang: 'Amoxicillin Syrup 60ml', jumlah: 1, dosis: '2x 1.5ml', aturanPakai: 'Sesudah Makan (Spuit)', hargaSatuan: 45000, subtotal: 45000 }
      ],
      racikanList: [
        {
          id: 'rac-1',
          namaRacikan: 'Racikan Anti-Muntah + Vitamin Infeksi 5 Bungkus',
          jumlahBungkus: 5,
          aturanPakai: '2x1 bungkus dicampur sedikit pakan basah',
          biayaJasaRacik: 15000,
          items: [
            { barangId: 'brg-10', namaObat: 'Doxycycline 100mg Tab', dosisDetail: '1/4 tab', jumlah: 2, hargaSatuan: 5000, subtotal: 10000 }
          ],
          totalHarga: 25000
        }
      ],
      pakanAnjuran: 'Royal Canin Recovery Wet (Sesuai Dosis)',
      catatanTambahan: 'Rencana terapi cairan infus RL 150ml/24jam selama rawat inap.',
      statusLanjutan: 'Rawat Inap',
      tanggalKontrolUlang: '2026-08-01'
    },
    lampiranDokumen: [
      { nama: 'Foto Klinis Mochi.jpg', url: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=500&auto=format&fit=crop&q=80', tipe: 'Foto' }
    ],
    totalBiaya: 320000,
    statusPembayaran: 'Lunas'
  },
  {
    id: 'rm-2',
    noRM: 'RM-2026-0002',
    pendaftaranId: 'pdf-3',
    pasienId: 'pas-3',
    dokterId: 'dok-2',
    tanggal: '2026-07-29',
    subjective: {
      keluhan: 'Gatal-gatal di punggung dan ekor',
      anamnesa: 'Banyak ketombe dan kerontokan melingkar di area leher & punggung.',
      makanMinum: 'Normal',
      durasiSakit: '1 Minggu'
    },
    objective: {
      beratBadan: 3.2,
      suhu: 38.5,
      frekuensiNapas: 24,
      detakJantung: 120,
      crt: '< 2 Detik',
      dehidrasi: 'Normal',
      pemeriksaanFisik: 'Lesi alopesia lingkar dengan eritema dan alopesia khas dermatofitosis (Jamur Microsporum).'
    },
    assessment: {
      diagnosaUtama: 'Ringworm / Dermatofitosis Fungal Infection',
      diagnosaBanding: 'Scabies, Alergi Pakan'
    },
    plan: {
      tindakanList: [
        { tindakanId: 'tdk-1', namaTindakan: 'Pemeriksaan & Konsultasi Dokter', tarif: 75000 },
        { tindakanId: 'tdk-8', namaTindakan: 'Grooming Medis Jamur/Kutu', tarif: 110000 }
      ],
      resepList: [
        { barangId: 'brg-13', namaBarang: 'Revolution Spot-On Cat 2.5-7.5kg', jumlah: 1, dosis: '1 Tetes Leher', aturanPakai: 'Sekali Tetes', hargaSatuan: 165000, subtotal: 165000 }
      ],
      racikanList: [],
      pakanAnjuran: 'Pakan tinggi Omega 3 & 6 untuk kesehatan kulit',
      catatanTambahan: 'Mandi shampo ketoconazole 2x seminggu.',
      statusLanjutan: 'Rawat Jalan',
      tanggalKontrolUlang: '2026-08-12'
    },
    totalBiaya: 350000,
    statusPembayaran: 'Lunas'
  },
  {
    id: 'rm-3',
    noRM: 'RM-2026-0003',
    pendaftaranId: 'pdf-6',
    pasienId: 'pas-9',
    dokterId: 'dok-2',
    tanggal: '2026-08-01',
    subjective: {
      keluhan: 'Vaksinasi booster tahunan Felocell 4',
      anamnesa: 'Kondisi sehat di rumah, tidak ada batuk, muntah, atau diare.',
      makanMinum: 'Normal',
      durasiSakit: 'Sehat'
    },
    objective: {
      beratBadan: 4.1,
      suhu: 38.3,
      frekuensiNapas: 22,
      detakJantung: 115,
      crt: '< 2 Detik',
      dehidrasi: 'Normal',
      pemeriksaanFisik: 'Kondisi fisik prima, jantung dan paru bersih, mukosa merah muda segar.'
    },
    assessment: {
      diagnosaUtama: 'Sehat (Fit for Vaccination)',
      diagnosaBanding: '-'
    },
    plan: {
      tindakanList: [
        { tindakanId: 'tdk-2', namaTindakan: 'Vaksinasi Kucing (Felocell 4)', tarif: 220000 }
      ],
      resepList: [],
      racikanList: [],
      catatanTambahan: 'Hindari memandikan kucing selama 7 hari paska vaksinasi.',
      statusLanjutan: 'Rawat Jalan',
      tanggalKontrolUlang: '2027-08-01'
    },
    totalBiaya: 220000,
    statusPembayaran: 'Lunas'
  }
];

const INITIAL_RAWAT_INAP: RawatInap[] = [
  {
    id: 'inap-1',
    pasienId: 'pas-1',
    noKandang: 'Kandang Kucing A-01',
    tanggalMasuk: '2026-07-28 11:30',
    dokterPenanggungJawabId: 'dok-1',
    diagnosaInap: 'Gastritis Akut + Dehidrasi Ringan',
    tarifPerHari: 100000,
    status: 'Aktif',
    monitoringLogs: [
      {
        id: 'mon-1',
        tanggalWaktu: '2026-07-28 16:00',
        shift: 'Siang',
        suhu: 39.0,
        nafsuMakan: 'Sedikit',
        babBak: 'Normal',
        kondisiUmum: 'Mulai responsif, mau minum sedikit',
        obatDiinjeksi: 'Injeksi Ondansetron 0.4ml, Infus RL 15 tpm',
        catatanPetugas: 'Monitoring tetesan infus terjaga lancar.',
        petugasName: 'Rina Staf'
      },
      {
        id: 'mon-2',
        tanggalWaktu: '2026-07-29 08:30',
        shift: 'Pagi',
        suhu: 38.6,
        nafsuMakan: 'Lahap',
        babBak: 'Normal',
        kondisiUmum: 'Suhu stabil, sudah mau makan wet food sendiri 1/2 kaleng.',
        obatDiinjeksi: 'Injeksi Vitamin Complex 0.5ml',
        catatanPetugas: 'Nafsu makan membaik signifikan.',
        petugasName: 'drh. Andi'
      },
      {
        id: 'mon-3',
        tanggalWaktu: '2026-07-30 19:00',
        shift: 'Malam',
        suhu: 38.4,
        nafsuMakan: 'Lahap',
        babBak: 'Normal',
        kondisiUmum: 'Mochi aktif meong, pernafasan normal, turgor bagus.',
        obatDiinjeksi: 'Injeksi Cefotaxime 0.3ml',
        catatanPetugas: 'Persiapan pelepasan infus besok jika stabil.',
        petugasName: 'Rina Staf'
      }
    ],
    catatanKhusus: 'Ganti perlak kandang tiap pagi, kucing manja minta dibelai'
  },
  {
    id: 'inap-2',
    pasienId: 'pas-4',
    noKandang: 'Kandang Kelinci C-02',
    tanggalMasuk: '2026-07-30 09:00',
    dokterPenanggungJawabId: 'dok-2',
    diagnosaInap: 'GI Stasis / Kembung Pencernaan Kelinci',
    tarifPerHari: 120000,
    status: 'Aktif',
    monitoringLogs: [
      {
        id: 'mon-201',
        tanggalWaktu: '2026-07-30 14:00',
        shift: 'Siang',
        suhu: 38.8,
        nafsuMakan: 'Muntah',
        babBak: 'Diare',
        kondisiUmum: 'Kelinci pasif, diberikan syringe feeding Oxbow Critical care 10ml.',
        obatDiinjeksi: 'Injeksi Cisapride + Metoclopramide 0.2ml',
        catatanPetugas: 'Pijat abdomen perlahan 15 menit.',
        petugasName: 'drh. Siska'
      },
      {
        id: 'mon-202',
        tanggalWaktu: '2026-07-31 08:00',
        shift: 'Pagi',
        suhu: 38.5,
        nafsuMakan: 'Sedikit',
        babBak: 'Normal',
        kondisiUmum: 'Mulai gerak aktif, mau kunyah timothy hay sedikit.',
        obatDiinjeksi: 'Injeksi Vitamin B-Complex 0.2ml',
        catatanPetugas: 'Poop bentuk bulat kecil mulai keluar.',
        petugasName: 'Rina Staf'
      }
    ],
    catatanKhusus: 'Berikan timothy hay segar melimpah di wadah'
  },
  {
    id: 'inap-3',
    pasienId: 'pas-2',
    noKandang: 'Kandang Anjing ICU-01',
    tanggalMasuk: '2026-07-15 10:00',
    tanggalKeluarAktif: '2026-07-18 14:00',
    dokterPenanggungJawabId: 'dok-3',
    diagnosaInap: 'Post-Op Pembersihan Luka Gigitan & Jahitan Kulit',
    tarifPerHari: 150000,
    status: 'Selesai / Pulang',
    monitoringLogs: [
      {
        id: 'mon-301',
        tanggalWaktu: '2026-07-15 16:00',
        shift: 'Siang',
        suhu: 38.7,
        nafsuMakan: 'Lahap',
        babBak: 'Normal',
        kondisiUmum: 'Sadar dari anestesi, luka kering tertutup perban.',
        obatDiinjeksi: 'Injeksi Cefazolin 1ml',
        catatanPetugas: 'Anjing memakai elizabeth collar.',
        petugasName: 'drh. Budi'
      }
    ],
    catatanKhusus: 'Wajib pakai e-collar selama di kandang'
  }
];

const INITIAL_JANJI_TEMU: JanjiTemu[] = [
  {
    id: 'jnj-1',
    pasienId: 'pas-2',
    dokterId: 'dok-2',
    tanggal: '2026-08-05',
    jam: '10:00',
    layanan: 'Vaksinasi Tahunan & Checkup',
    catatan: 'Owner minta jam pagi sebelum berangkat kantor',
    status: 'Disetujui',
    noHpPengingat: '085711223344'
  },
  {
    id: 'jnj-2',
    pasienId: 'pas-3',
    dokterId: 'dok-1',
    tanggal: '2026-08-06',
    jam: '14:00',
    layanan: 'Steril Betina (Spay)',
    catatan: 'Puasa makan 8 jam sebelum operasi',
    status: 'Menunggu Konfirmasi',
    noHpPengingat: '081388990011'
  },
  {
    id: 'jnj-3',
    pasienId: 'pas-6',
    dokterId: 'dok-3',
    tanggal: '2026-08-07',
    jam: '11:30',
    layanan: 'Rontgen Panggul & Sendi',
    catatan: 'Pemeriksaan rutin evaluasi kaki',
    status: 'Disetujui',
    noHpPengingat: '085299001122'
  },
  {
    id: 'jnj-4',
    pasienId: 'pas-10',
    dokterId: 'dok-4',
    tanggal: '2026-08-08',
    jam: '16:00',
    layanan: 'Dental Scaling Teeth Cleaning',
    catatan: 'Puasa 6 jam sebelumnya',
    status: 'Disetujui',
    noHpPengingat: '085677889900'
  }
];

const INITIAL_VAKSINASI: RiwayatVaksinasi[] = [
  {
    id: 'vks-1',
    pasienId: 'pas-1',
    namaVaksin: 'Vaksin Rabies Defensor 3',
    tanggalVaksin: '2025-08-10',
    tanggalVaksinUlang: '2026-08-10',
    dokterId: 'dok-1',
    batchNo: 'BATCH-RAB-2025-99',
    keterangan: 'Vaksinasi Rabies tahunan kondisi sehat'
  },
  {
    id: 'vks-2',
    pasienId: 'pas-1',
    namaVaksin: 'Felocell 4 (Cat)',
    tanggalVaksin: '2025-09-01',
    tanggalVaksinUlang: '2026-09-01',
    dokterId: 'dok-1',
    batchNo: 'BATCH-FEL-8812',
    keterangan: 'Booster Felocell 4'
  },
  {
    id: 'vks-3',
    pasienId: 'pas-2',
    namaVaksin: 'Vanguard Plus 5/L',
    tanggalVaksin: '2025-08-15',
    tanggalVaksinUlang: '2026-08-15',
    dokterId: 'dok-3',
    batchNo: 'BATCH-VAN-1102',
    keterangan: 'Vaksin lengkap anjing'
  },
  {
    id: 'vks-4',
    pasienId: 'pas-9',
    namaVaksin: 'Felocell 4 (Cat)',
    tanggalVaksin: '2026-08-01',
    tanggalVaksinUlang: '2027-08-01',
    dokterId: 'dok-2',
    batchNo: 'BATCH-FEL-9021',
    keterangan: 'Vaksinasi tahunan lengkap'
  }
];

const INITIAL_TRANSAKSI: Transaksi[] = [
  {
    id: 'trx-1',
    noNota: 'INV-20260728-001',
    tanggal: '2026-07-28 12:00',
    pendaftaranId: 'pdf-1',
    rekamMedisId: 'rm-1',
    pasienId: 'pas-1',
    namaPelanggan: 'Budi Santoso (Mochi)',
    typeTransaksi: 'Rekam Medis',
    items: [
      { id: 'ti-1', jenis: 'Tindakan', namaItem: 'Pemeriksaan & Konsultasi Dokter', jumlah: 1, hargaSatuan: 75000, subtotal: 75000 },
      { id: 'ti-2', jenis: 'Tindakan', namaItem: 'Pemasangan IV Line & Infus Therapy', jumlah: 1, hargaSatuan: 75000, subtotal: 75000 },
      { id: 'ti-3', jenis: 'Obat', namaItem: 'Amoxicillin Syrup 60ml', jumlah: 1, hargaSatuan: 45000, subtotal: 45000 },
      { id: 'ti-4', jenis: 'Obat Racikan', namaItem: 'Racikan Anti-Muntah + Vitamin 5 Bungkus', jumlah: 1, hargaSatuan: 25000, subtotal: 25000 },
      { id: 'ti-5', jenis: 'Rawat Inap', namaItem: 'Perawatan Rawat Inap Per Hari', jumlah: 1, hargaSatuan: 100000, subtotal: 100000 }
    ],
    subtotal: 320000,
    diskon: 0,
    pajak: 0,
    grandTotal: 320000,
    metodePembayaran: 'Transfer QRIS',
    jumlahBayar: 320000,
    kembalian: 0,
    status: 'Lunas',
    kasirId: 'usr-3'
  },
  {
    id: 'trx-2',
    noNota: 'INV-20260729-002',
    tanggal: '2026-07-29 15:30',
    namaPelanggan: 'Dewi Lestari (Penjualan PetShop)',
    typeTransaksi: 'Penjualan Direct (PetShop)',
    items: [
      { id: 'ti-6', jenis: 'Barang/Pakan', namaItem: 'Pro Plan Cat Urinary Optirenal 1.5kg', jumlah: 1, hargaSatuan: 240000, subtotal: 240000 },
      { id: 'ti-7', jenis: 'Barang/Pakan', namaItem: 'Royal Canin Recovery Wet 195g', jumlah: 2, hargaSatuan: 55000, subtotal: 110000 }
    ],
    subtotal: 350000,
    diskon: 10000,
    pajak: 0,
    grandTotal: 340000,
    metodePembayaran: 'Tunai',
    jumlahBayar: 350000,
    kembalian: 10000,
    status: 'Lunas',
    kasirId: 'usr-3'
  },
  {
    id: 'trx-3',
    noNota: 'INV-20260801-003',
    tanggal: '2026-08-01 16:15',
    pendaftaranId: 'pdf-6',
    rekamMedisId: 'rm-3',
    pasienId: 'pas-9',
    namaPelanggan: 'Maya Putri (Luna)',
    typeTransaksi: 'Rekam Medis',
    items: [
      { id: 'ti-8', jenis: 'Tindakan', namaItem: 'Vaksinasi Kucing (Felocell 4)', jumlah: 1, hargaSatuan: 220000, subtotal: 220000 }
    ],
    subtotal: 220000,
    diskon: 0,
    pajak: 0,
    grandTotal: 220000,
    metodePembayaran: 'Debit/Kredit',
    jumlahBayar: 220000,
    kembalian: 0,
    status: 'Lunas',
    kasirId: 'usr-3'
  }
];

const INITIAL_PEMBELIAN: PembelianBarang[] = [
  {
    id: 'pmb-1',
    noFaktur: 'PO-SUP-8821',
    tanggal: '2026-07-20',
    namaSupplier: 'PT Kalbe Animal Health',
    items: [
      { barangId: 'brg-1', namaBarang: 'Amoxicillin Syrup 60ml', jumlah: 20, hargaBeli: 25000, subtotal: 500000, expiredDate: '2027-12-31' },
      { barangId: 'brg-6', namaBarang: 'Cairan Infus Ringer Lactate 500ml', jumlah: 30, hargaBeli: 16000, subtotal: 480000, expiredDate: '2028-05-30' }
    ],
    grandTotal: 980000,
    status: 'Selesai'
  },
  {
    id: 'pmb-2',
    noFaktur: 'PO-SUP-9012',
    tanggal: '2026-07-25',
    namaSupplier: 'CV Vet Medika Nusantara',
    items: [
      { barangId: 'brg-5', namaBarang: 'Vaksin Felocell 4 (Cat)', jumlah: 15, hargaBeli: 110000, subtotal: 1650000, expiredDate: '2027-09-15' },
      { barangId: 'brg-11', namaBarang: 'Vaksin Vanguard Plus 5/L (Dog)', jumlah: 10, hargaBeli: 130000, subtotal: 1300000, expiredDate: '2027-11-28' }
    ],
    grandTotal: 2950000,
    status: 'Selesai'
  }
];

const INITIAL_FEEDBACK: FeedbackOwner[] = [
  {
    id: 'fb-1',
    pasienId: 'pas-1',
    namaOwner: 'Budi Santoso',
    rating: 5,
    komentar: 'Pelayanan drh. Andi sangat ramah dan jelas penjelasannya. Mochi dirawat inap 2 hari langsung sehat kembali!',
    tanggal: '2026-07-29',
    balasanKlinik: 'Terima kasih Pak Budi, sehat selalu untuk Mochi!'
  },
  {
    id: 'fb-2',
    pasienId: 'pas-2',
    namaOwner: 'Siti Rahmawati',
    rating: 5,
    komentar: 'Fasilitas klinik bersih, tidak bau, dokter dan perawat sangat telaten memegang Milo.',
    tanggal: '2026-07-25'
  },
  {
    id: 'fb-3',
    pasienId: 'pas-4',
    namaOwner: 'Rian Kurniawan',
    rating: 5,
    komentar: 'Sangat direkomendasikan untuk kelinci & hewan eksotis. drh. Siska paham betul penanganan GI stasis.',
    tanggal: '2026-07-31',
    balasanKlinik: 'Terima kasih Mas Rian, semoga Clover sehat terus!'
  }
];

const INITIAL_KLINIK: DataKlinik = {
  namaKlinik: 'VetCare Animal Clinic & Pet Hospital',
  alamat: 'Jl. Ahmad Yani No. 108, Sumbersari, Jember, Jawa Timur',
  noTelp: '(0331) 489221',
  noWhatsApp: '6281234567890',
  email: 'info@vetcareclinic.co.id',
  website: 'www.vetcareclinic.co.id',
  logoUrl: 'https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=150&auto=format&fit=crop&q=80',
  headerNota: 'VETCARE ANIMAL CLINIC & PET HOSPITAL\nIzin Operasional No: 503/VET/2024\nJl. Ahmad Yani No. 108, Jember | WA: 0812-3456-7890',
  footerNota: 'Terima kasih atas kepercayaan Anda merawat anabul tercinta di VetCare!\nSemoga lekas sembuh. Kontak Emergency WA: 0812-3456-7890',
  npwp: '88.921.401.9-623.000',
  namaPenanggungJawab: 'drh. Andi Pratama, M.Si'
};

const INITIAL_SETTINGS: AppSettings = {
  printerThermalWidth: '58mm',
  autoPrintReceipt: true,
  alertStokMinimumDefault: 5,
  pPNPersen: 0,
  autoSendWaReminder: true,
  themeMode: 'light'
};

const INITIAL_SUPPLIER: Supplier[] = [
  { id: 'sup-1', namaSupplier: 'PT Kalbe Animal Health', kontak: 'Bpk. Hendra', noHp: '081234567000', alamat: 'Surabaya, Jawa Timur' },
  { id: 'sup-2', namaSupplier: 'CV Vet Medika Nusantara', kontak: 'Ibu Ratna', noHp: '085711223300', alamat: 'Sidoarjo, Jawa Timur' },
  { id: 'sup-3', namaSupplier: 'PT Zoetis Indonesia', kontak: 'Bpk. Ridwan', noHp: '081399881122', alamat: 'Jakarta Selatan' },
  { id: 'sup-4', namaSupplier: 'Royal Canin Petfood Distributor', kontak: 'Ibu Siska', noHp: '081122334455', alamat: 'Malang, Jawa Timur' }
];

const INITIAL_WA_CONFIG: WhatsAppConfig = {
  provider: 'fonnte',
  apiKey: 'FONNTE_DEMO_KEY_9823120938',
  senderPhone: '081234567890',
  statusDevice: 'terhubung',
  active: true,
  autoReminders: {
    janjiTemu: true,
    kontrolUlang: true,
    vaksinasi: true,
    notaPembayaran: true,
    pengingatPakan: true,
  }
};

const INITIAL_WA_TEMPLATES: WhatsAppTemplate[] = [
  {
    id: 'tmpl-1',
    kategori: 'janji_temu',
    judul: 'Pengingat Janji Temu / Konsultasi',
    pesan: 'Halo Kak {nama_owner}, ini pengingat dari {nama_klinik}. Pasien {nama_pasien} memiliki jadwal janji temu dengan {nama_dokter} pada tanggal {tanggal} pukul {jam}. Mohon hadir 15 menit sebelum jadwal. Terima kasih!',
    variablePlaceholder: ['{nama_owner}', '{nama_pasien}', '{nama_klinik}', '{nama_dokter}', '{tanggal}', '{jam}']
  },
  {
    id: 'tmpl-2',
    kategori: 'kontrol_ulang',
    judul: 'Pengingat Kontrol Ulang Medis',
    pesan: 'Halo Kak {nama_owner}, hewan kesayangan Anda ({nama_pasien}) dijadwalkan untuk kontrol ulang kesehatan pada tanggal {tanggal} di {nama_klinik}. Jangan lupa membawa buku rekam medis. Salam sehat!',
    variablePlaceholder: ['{nama_owner}', '{nama_pasien}', '{nama_klinik}', '{tanggal}']
  },
  {
    id: 'tmpl-3',
    kategori: 'vaksinasi',
    judul: 'Pengingat Jadwal Vaksinasi Ulang',
    pesan: 'Halo Kak {nama_owner}, vaksinasi tahunan/rutin untuk {nama_pasien} sudah mendekati jatuh tempo pada {tanggal}. Silakan hubungi {nama_klinik} untuk booking jadwal vaksinasi agar imunitas anabul tetap terjaga!',
    variablePlaceholder: ['{nama_owner}', '{nama_pasien}', '{nama_klinik}', '{tanggal}']
  },
  {
    id: 'tmpl-4',
    kategori: 'nota_pembayaran',
    judul: 'Kirim Nota & Struk Pembayaran Digital',
    pesan: 'Terima kasih telah mempercayakan perawatan {nama_pasien} di {nama_klinik}.\n\nNo Nota: {no_nota}\nTotal Pembayaran: Rp {total_bayar}\nMetode: {metode_bayar}\n\nStruk digital dan rincian obat dapat Anda lihat sewaktu-waktu. Semoga {nama_pasien} lekas sembuh!',
    variablePlaceholder: ['{nama_owner}', '{nama_pasien}', '{nama_klinik}', '{no_nota}', '{total_bayar}', '{metode_bayar}']
  },
  {
    id: 'tmpl-5',
    kategori: 'promosi',
    judul: 'Informasi Promo & Diskon Petshop',
    pesan: 'Spesial untuk Kak {nama_owner}! Dapatkan diskon 15% untuk grooming & pakan khusus di {nama_klinik} bulan ini. Kunjungi kami sebelum promo berakhir tanggal {tanggal}.',
    variablePlaceholder: ['{nama_owner}', '{nama_klinik}', '{tanggal}']
  }
];

const INITIAL_WA_LOGS: WhatsAppLog[] = [
  {
    id: 'walog-1',
    tanggal: '2026-08-03 09:30',
    noHp: '081234567891',
    namaPenerima: 'Bpk. Ahmad Subagyo',
    pesan: 'Halo Kak Bpk. Ahmad Subagyo, ini pengingat dari Klinik Hewan VetCare. Pasien Milo memiliki jadwal janji temu dengan drh. Andi Pratama, M.Si pada tanggal 2026-08-04 pukul 10:00.',
    status: 'terkirim',
    kategori: 'Janji Temu'
  },
  {
    id: 'walog-2',
    tanggal: '2026-08-03 11:15',
    noHp: '081298765432',
    namaPenerima: 'Ibu Ratna Dewi',
    pesan: 'Terima kasih telah mempercayakan perawatan Choco di Klinik Hewan VetCare. No Nota: NOTA-20260803-001. Total Pembayaran: Rp 185.000.',
    status: 'terkirim',
    kategori: 'Nota Pembayaran'
  },
  {
    id: 'walog-3',
    tanggal: '2026-08-02 16:45',
    noHp: '081377889900',
    namaPenerima: 'Ibu Maya',
    pesan: 'Halo Kak Ibu Maya, vaksinasi rutin untuk Luna sudah mendekati jatuh tempo pada 2026-08-10.',
    status: 'terkirim',
    kategori: 'Vaksinasi'
  }
];

// ==========================================
// STORAGE HELPER METHODS & SQL DATABASE SYNC
// ==========================================

type StorageListener = () => void;
const storageListeners: Set<StorageListener> = new Set();
let sqlSyncTimeout: any = null;

function notifyListeners() {
  storageListeners.forEach((fn) => {
    try {
      fn();
    } catch (e) {
      console.error('Storage listener error:', e);
    }
  });
}

export function triggerSqlSync() {
  if (sqlSyncTimeout) clearTimeout(sqlSyncTimeout);
  sqlSyncTimeout = setTimeout(async () => {
    try {
      const payload: SqlSyncPayload = {
        version: CURRENT_SEED_VERSION,
        updatedAt: new Date().toISOString(),
        users: storageService.getUsers(),
        dokter: storageService.getDokter(),
        pasien: storageService.getPasien(),
        barang: storageService.getBarang(),
        tindakan: storageService.getTindakan(),
        pakan: storageService.getPakan(),
        spesies: storageService.getSpesies(),
        pendaftaran: storageService.getPendaftaran(),
        rekamMedis: storageService.getRekamMedis(),
        rawatInap: storageService.getRawatInap(),
        janjiTemu: storageService.getJanjiTemu(),
        vaksinasi: storageService.getVaksinasi(),
        transaksi: storageService.getTransaksi(),
        pembelian: storageService.getPembelian(),
        supplier: storageService.getSupplier(),
        feedback: storageService.getFeedback(),
        klinik: storageService.getKlinik(),
        settings: storageService.getSettings(),
        rbacConfig: storageService.getRBACConfig(),
        waConfig: storageService.getWhatsAppConfig(),
        waTemplates: storageService.getWhatsAppTemplates(),
        waLogs: storageService.getWhatsAppLogs(),
      };
      await saveClinicDataToSql(payload);
    } catch (e) {
      console.error('Error auto-syncing to SQL Database:', e);
    }
  }, 400);
}

function getItem<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key);
    if (!data) return defaultValue;
    return JSON.parse(data);
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T, skipSqlSync = false): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    notifyListeners();
    if (!skipSqlSync && key !== STORAGE_KEYS.ACTIVE_USER && key !== STORAGE_KEYS.SEED_VERSION) {
      triggerSqlSync();
    }
  } catch (e) {
    console.error('Error saving storage record:', e);
  }
}

export const DEFAULT_RBAC_MODULES: ModulePermissionItem[] = [
  {
    id: 'dashboard',
    namaModule: 'Dashboard Utama & Statistik',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Melihat ringkasan indikator performa, antrean aktif, rawat inap, dan grafik harian',
    allowedRoles: ['super_admin', 'admin', 'staf', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      staf: { canView: true, canCreate: true, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'pendaftaran',
    namaModule: 'Pendaftaran & Registrasi Pasien',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Mendaftarkan pasien baru, membuat nomor antrean, dan mencetak tiket antrean',
    allowedRoles: ['super_admin', 'admin', 'staf'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
    }
  },
  {
    id: 'pasien',
    namaModule: 'Data Rekam Pasien & Client (Owner)',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Kelola data identitas hewan, pemilik, riwayat medis, dan dokumen cetak kartu pasien',
    allowedRoles: ['super_admin', 'admin', 'staf', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: false },
    }
  },
  {
    id: 'rekam_medis',
    namaModule: 'Pemeriksaan Medis (SOAP) & Resep',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Pemeriksaan fisik (Subjektif, Objektif, Asesmen, Plan), resep obat, tindakan medis, & rujukan',
    allowedRoles: ['super_admin', 'admin', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'rawat_jalan',
    namaModule: 'Layanan Rawat Jalan',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Monitoring pelayanan rawat jalan, tindakan berulang, dan kontrol ulang pasien',
    allowedRoles: ['super_admin', 'admin', 'staf', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      staf: { canView: true, canCreate: true, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'rawat_inap',
    namaModule: 'Rawat Inap & Monitoring Pasien',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Monitoring kondisi vital, pemberian pakan/obat berkala, dan manajemen kandang rawat inap',
    allowedRoles: ['super_admin', 'admin', 'staf', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: false },
    }
  },
  {
    id: 'janji_temu',
    namaModule: 'Janji Temu (Appointment)',
    kategori: 'Pelayanan Medis',
    deskripsi: 'Penjadwalan reservasi pemeriksaan, grooming, vaksinasi, dan panggilan rumah (home visit)',
    allowedRoles: ['super_admin', 'admin', 'staf', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
    }
  },
  {
    id: 'kasir',
    namaModule: 'Kasir Pembayaran Nota & Tagihan',
    kategori: 'Kasir & Inventaris',
    deskripsi: 'Proses tagihan rekam medis, metode pembayaran (Tunai/QRIS/Transfer), & cetak nota thermal 58/80mm',
    allowedRoles: ['super_admin', 'admin', 'staf'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
    }
  },
  {
    id: 'penjualan',
    namaModule: 'Kasir PetShop Direct',
    kategori: 'Kasir & Inventaris',
    deskripsi: 'Penjualan produk makanan, aksesoris, & vitamin langsung tanpa antrean medis',
    allowedRoles: ['super_admin', 'admin', 'staf'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
    }
  },
  {
    id: 'inventory',
    namaModule: 'Stok Obat & Barang PetShop',
    kategori: 'Kasir & Inventaris',
    deskripsi: 'Kelola stok obat, tanggal kedaluwarsa, harga jual/beli, rak penyimpanan, & alert minimum stok',
    allowedRoles: ['super_admin', 'admin', 'staf', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: false, canEdit: false, canDelete: false, canExport: true },
      staf: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
    }
  },
  {
    id: 'pembelian',
    namaModule: 'Pembelian Stok & Restock Supplier',
    kategori: 'Kasir & Inventaris',
    deskripsi: 'Pencatatan faktur masuk barang dari distributor/supplier dan update otomatis stok',
    allowedRoles: ['super_admin', 'admin', 'staf'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: true, canCreate: true, canEdit: false, canDelete: false, canExport: true },
    }
  },
  {
    id: 'master',
    namaModule: 'Master Data & Jadwal Dokter',
    kategori: 'Manajemen & Laporan',
    deskripsi: 'Kelola data dokter, SIP, tarif jasa medis, spesies hewan, & pengguna sistem',
    allowedRoles: ['super_admin', 'admin'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'laporan',
    namaModule: 'Laporan Keuangan & Omset',
    kategori: 'Manajemen & Laporan',
    deskripsi: 'Rekapitulasi omset, metode pembayaran, rincian obat vs tindakan, & ekspor Excel/PDF',
    allowedRoles: ['super_admin', 'admin'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'laporan_laba',
    namaModule: 'Laporan Laba Penjualan Produk',
    kategori: 'Manajemen & Laporan',
    deskripsi: 'Laporan margin keuntungan bersih produk petshop dan harga pokok penjualan (HPP)',
    allowedRoles: ['super_admin', 'admin'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'laporan_tren_penyakit',
    namaModule: 'Laporan Tren Penyakit & Epidemiologi',
    kategori: 'Manajemen & Laporan',
    deskripsi: 'Analisis statistik diagnosa terbanyak per bulan, jenis hewan paling rentan, dan tren obat',
    allowedRoles: ['super_admin', 'admin', 'dokter'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: true, canCreate: false, canEdit: false, canDelete: false, canExport: true },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'pengaturan',
    namaModule: 'Pengaturan Identitas & Printer Thermal',
    kategori: 'Sistem & Keamanan',
    deskripsi: 'Set profil klinik, nama PJ, logo aplikasi, koneksi printer thermal 58/80mm, & backup database',
    allowedRoles: ['super_admin', 'admin'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'hak_akses',
    namaModule: 'Hak Akses & Role (RBAC)',
    kategori: 'Sistem & Keamanan',
    deskripsi: 'Konfigurasi matriks hak akses modul, kelola role pengguna, dan kebijakan keamanan sistem',
    allowedRoles: ['super_admin', 'admin'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: false, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  },
  {
    id: 'whatsapp',
    namaModule: 'Integrasi WhatsApp Gateway',
    kategori: 'Sistem & Keamanan',
    deskripsi: 'Pengaturan API WhatsApp, pengingat otomatis (Janji Temu, Kontrol, Vaksinasi, Struk), template pesan, dan log pengiriman',
    allowedRoles: ['super_admin', 'admin'],
    roleActions: {
      super_admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      admin: { canView: true, canCreate: true, canEdit: true, canDelete: true, canExport: true },
      dokter: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
      staf: { canView: false, canCreate: false, canEdit: false, canDelete: false, canExport: false },
    }
  }
];

export const INITIAL_RBAC_CONFIG: RBACConfig = {
  modules: DEFAULT_RBAC_MODULES,
  updatedAt: new Date().toISOString(),
  updatedBy: 'System Default'
};

export const storageService = {
  checkSeedVersion() {
    const storedVer = localStorage.getItem(STORAGE_KEYS.SEED_VERSION);
    if (storedVer !== CURRENT_SEED_VERSION) {
      localStorage.setItem(STORAGE_KEYS.SEED_VERSION, CURRENT_SEED_VERSION);
    }
  },

  applySqlData(data: SqlSyncPayload) {
    if (data.users && Array.isArray(data.users) && data.users.length > 0) setItem(STORAGE_KEYS.USERS, data.users, true);
    if (data.dokter && Array.isArray(data.dokter) && data.dokter.length > 0) setItem(STORAGE_KEYS.DOKTER, data.dokter, true);
    if (data.pasien && Array.isArray(data.pasien) && data.pasien.length > 0) setItem(STORAGE_KEYS.PASIEN, data.pasien, true);
    if (data.barang && Array.isArray(data.barang) && data.barang.length > 0) setItem(STORAGE_KEYS.BARANG, data.barang, true);
    if (data.tindakan && Array.isArray(data.tindakan) && data.tindakan.length > 0) setItem(STORAGE_KEYS.TINDAKAN, data.tindakan, true);
    if (data.pakan && Array.isArray(data.pakan) && data.pakan.length > 0) setItem(STORAGE_KEYS.PAKAN, data.pakan, true);
    if (data.spesies && Array.isArray(data.spesies) && data.spesies.length > 0) setItem(STORAGE_KEYS.SPESIES, data.spesies, true);
    if (data.pendaftaran && Array.isArray(data.pendaftaran) && data.pendaftaran.length > 0) setItem(STORAGE_KEYS.PENDAFTARAN, data.pendaftaran, true);
    if (data.rekamMedis && Array.isArray(data.rekamMedis) && data.rekamMedis.length > 0) setItem(STORAGE_KEYS.REKAM_MEDIS, data.rekamMedis, true);
    if (data.rawatInap && Array.isArray(data.rawatInap) && data.rawatInap.length > 0) setItem(STORAGE_KEYS.RAWAT_INAP, data.rawatInap, true);
    if (data.janjiTemu && Array.isArray(data.janjiTemu) && data.janjiTemu.length > 0) setItem(STORAGE_KEYS.JANJI_TEMU, data.janjiTemu, true);
    if (data.vaksinasi && Array.isArray(data.vaksinasi) && data.vaksinasi.length > 0) setItem(STORAGE_KEYS.VAKSINASI, data.vaksinasi, true);
    if (data.transaksi && Array.isArray(data.transaksi) && data.transaksi.length > 0) setItem(STORAGE_KEYS.TRANSAKSI, data.transaksi, true);
    if (data.pembelian && Array.isArray(data.pembelian) && data.pembelian.length > 0) setItem(STORAGE_KEYS.PEMBELIAN, data.pembelian, true);
    if (data.supplier && Array.isArray(data.supplier) && data.supplier.length > 0) setItem(STORAGE_KEYS.SUPPLIER, data.supplier, true);
    if (data.feedback && Array.isArray(data.feedback) && data.feedback.length > 0) setItem(STORAGE_KEYS.FEEDBACK, data.feedback, true);
    if (data.klinik && typeof data.klinik === 'object') setItem(STORAGE_KEYS.KLINIK, data.klinik, true);
    if (data.settings && typeof data.settings === 'object') setItem(STORAGE_KEYS.SETTINGS, data.settings, true);
    if (data.rbacConfig && typeof data.rbacConfig === 'object') setItem(STORAGE_KEYS.RBAC, data.rbacConfig, true);
    if (data.waConfig && typeof data.waConfig === 'object') setItem(STORAGE_KEYS.WA_CONFIG, data.waConfig, true);
    if (data.waTemplates && Array.isArray(data.waTemplates)) setItem(STORAGE_KEYS.WA_TEMPLATES, data.waTemplates, true);
    if (data.waLogs && Array.isArray(data.waLogs)) setItem(STORAGE_KEYS.WA_LOGS, data.waLogs, true);
    notifyListeners();
  },

  subscribe(listener: () => void): () => void {
    storageListeners.add(listener);
    return () => {
      storageListeners.delete(listener);
    };
  },

  syncToSqlNow() {
    triggerSqlSync();
  },

  async initStorage(): Promise<void> {
    this.checkSeedVersion();
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) setItem(STORAGE_KEYS.USERS, INITIAL_USERS, true);
    if (!localStorage.getItem(STORAGE_KEYS.DOKTER)) setItem(STORAGE_KEYS.DOKTER, INITIAL_DOKTER, true);
    if (!localStorage.getItem(STORAGE_KEYS.PASIEN)) setItem(STORAGE_KEYS.PASIEN, INITIAL_PASIEN, true);
    if (!localStorage.getItem(STORAGE_KEYS.BARANG)) setItem(STORAGE_KEYS.BARANG, INITIAL_BARANG, true);
    if (!localStorage.getItem(STORAGE_KEYS.TINDAKAN)) setItem(STORAGE_KEYS.TINDAKAN, INITIAL_TINDAKAN, true);
    if (!localStorage.getItem(STORAGE_KEYS.PAKAN)) setItem(STORAGE_KEYS.PAKAN, INITIAL_PAKAN, true);
    if (!localStorage.getItem(STORAGE_KEYS.SPESIES)) setItem(STORAGE_KEYS.SPESIES, INITIAL_SPESIES, true);
    if (!localStorage.getItem(STORAGE_KEYS.PENDAFTARAN)) setItem(STORAGE_KEYS.PENDAFTARAN, INITIAL_PENDAFTARAN, true);
    if (!localStorage.getItem(STORAGE_KEYS.REKAM_MEDIS)) setItem(STORAGE_KEYS.REKAM_MEDIS, INITIAL_REKAM_MEDIS, true);
    if (!localStorage.getItem(STORAGE_KEYS.RAWAT_INAP)) setItem(STORAGE_KEYS.RAWAT_INAP, INITIAL_RAWAT_INAP, true);
    if (!localStorage.getItem(STORAGE_KEYS.JANJI_TEMU)) setItem(STORAGE_KEYS.JANJI_TEMU, INITIAL_JANJI_TEMU, true);
    if (!localStorage.getItem(STORAGE_KEYS.VAKSINASI)) setItem(STORAGE_KEYS.VAKSINASI, INITIAL_VAKSINASI, true);
    if (!localStorage.getItem(STORAGE_KEYS.TRANSAKSI)) setItem(STORAGE_KEYS.TRANSAKSI, INITIAL_TRANSAKSI, true);
    if (!localStorage.getItem(STORAGE_KEYS.PEMBELIAN)) setItem(STORAGE_KEYS.PEMBELIAN, INITIAL_PEMBELIAN, true);
    if (!localStorage.getItem(STORAGE_KEYS.SUPPLIER)) setItem(STORAGE_KEYS.SUPPLIER, INITIAL_SUPPLIER, true);
    if (!localStorage.getItem(STORAGE_KEYS.FEEDBACK)) setItem(STORAGE_KEYS.FEEDBACK, INITIAL_FEEDBACK, true);
    if (!localStorage.getItem(STORAGE_KEYS.KLINIK)) setItem(STORAGE_KEYS.KLINIK, INITIAL_KLINIK, true);
    if (!localStorage.getItem(STORAGE_KEYS.SETTINGS)) setItem(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS, true);
    if (!localStorage.getItem(STORAGE_KEYS.ACTIVE_USER)) setItem(STORAGE_KEYS.ACTIVE_USER, INITIAL_USERS[0], true);
    if (!localStorage.getItem(STORAGE_KEYS.RBAC)) setItem(STORAGE_KEYS.RBAC, INITIAL_RBAC_CONFIG, true);
    if (!localStorage.getItem(STORAGE_KEYS.WA_CONFIG)) setItem(STORAGE_KEYS.WA_CONFIG, INITIAL_WA_CONFIG, true);
    if (!localStorage.getItem(STORAGE_KEYS.WA_TEMPLATES)) setItem(STORAGE_KEYS.WA_TEMPLATES, INITIAL_WA_TEMPLATES, true);
    if (!localStorage.getItem(STORAGE_KEYS.WA_LOGS)) setItem(STORAGE_KEYS.WA_LOGS, INITIAL_WA_LOGS, true);

    // Boot: Fetch from SQL Database & Sync initial seed
    try {
      const sqlData = await fetchClinicDataFromSql();
      if (sqlData && sqlData.users && sqlData.users.length > 0) {
        this.applySqlData(sqlData);
      } else {
        // First time initialization: Seed SQL database so database has initial users & clinic configuration
        triggerSqlSync();
      }
    } catch (e) {
      console.warn('Notice loading from SQL database:', e);
    }
  },

  // WhatsApp Methods
  getWhatsAppConfig(): WhatsAppConfig {
    return getItem<WhatsAppConfig>(STORAGE_KEYS.WA_CONFIG, INITIAL_WA_CONFIG);
  },
  saveWhatsAppConfig(config: WhatsAppConfig) {
    setItem(STORAGE_KEYS.WA_CONFIG, config);
  },
  getWhatsAppTemplates(): WhatsAppTemplate[] {
    return getItem<WhatsAppTemplate[]>(STORAGE_KEYS.WA_TEMPLATES, INITIAL_WA_TEMPLATES);
  },
  saveWhatsAppTemplates(templates: WhatsAppTemplate[]) {
    setItem(STORAGE_KEYS.WA_TEMPLATES, templates);
  },
  getWhatsAppLogs(): WhatsAppLog[] {
    return getItem<WhatsAppLog[]>(STORAGE_KEYS.WA_LOGS, INITIAL_WA_LOGS);
  },
  saveWhatsAppLogs(logs: WhatsAppLog[]) {
    setItem(STORAGE_KEYS.WA_LOGS, logs);
  },
  addWhatsAppLog(logData: Omit<WhatsAppLog, 'id'>): WhatsAppLog[] {
    const logs = this.getWhatsAppLogs();
    const newLog: WhatsAppLog = {
      ...logData,
      id: `walog-${Date.now()}`
    };
    const updated = [newLog, ...logs];
    this.saveWhatsAppLogs(updated);
    return updated;
  },

  // RBAC Config
  getRBACConfig(): RBACConfig {
    return getItem<RBACConfig>(STORAGE_KEYS.RBAC, INITIAL_RBAC_CONFIG);
  },
  saveRBACConfig(config: RBACConfig) {
    setItem(STORAGE_KEYS.RBAC, config);
  },

  // Active User / Auth
  getActiveUser(): User | null {
    return getItem<User | null>(STORAGE_KEYS.ACTIVE_USER, INITIAL_USERS[0]);
  },
  setActiveUser(user: User | null) {
    if (user === null) {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
    } else {
      setItem(STORAGE_KEYS.ACTIVE_USER, user);
    }
  },
  logout() {
    this.setActiveUser(null);
  },

  // Users
  getUsers(): User[] { return getItem<User[]>(STORAGE_KEYS.USERS, INITIAL_USERS); },
  getUserList(): User[] { return this.getUsers(); },
  saveUsers(users: User[]) { setItem(STORAGE_KEYS.USERS, users); },
  saveUserList(users: User[]) { this.saveUsers(users); },

  // Dokter
  getDokter(): Dokter[] { return getItem<Dokter[]>(STORAGE_KEYS.DOKTER, INITIAL_DOKTER); },
  getDokterList(): Dokter[] { return this.getDokter(); },
  saveDokter(dokter: Dokter[]) { setItem(STORAGE_KEYS.DOKTER, dokter); },
  saveDokterList(dokter: Dokter[]) { this.saveDokter(dokter); },

  // Pasien
  getPasien(): Pasien[] { return getItem<Pasien[]>(STORAGE_KEYS.PASIEN, INITIAL_PASIEN); },
  getPasienList(): Pasien[] { return this.getPasien(); },
  savePasien(pasien: Pasien[]) { setItem(STORAGE_KEYS.PASIEN, pasien); },
  savePasienList(pasien: Pasien[]) { this.savePasien(pasien); },

  // Barang / Stok
  getBarang(): Barang[] { return getItem<Barang[]>(STORAGE_KEYS.BARANG, INITIAL_BARANG); },
  getBarangList(): Barang[] { return this.getBarang(); },
  saveBarang(barang: Barang[]) { setItem(STORAGE_KEYS.BARANG, barang); },
  saveBarangList(barang: Barang[]) { this.saveBarang(barang); },

  // Tindakan
  getTindakan(): Tindakan[] { return getItem<Tindakan[]>(STORAGE_KEYS.TINDAKAN, INITIAL_TINDAKAN); },
  getTindakanList(): Tindakan[] { return this.getTindakan(); },
  saveTindakan(tindakan: Tindakan[]) { setItem(STORAGE_KEYS.TINDAKAN, tindakan); },
  saveTindakanList(tindakan: Tindakan[]) { this.saveTindakan(tindakan); },

  // Pakan
  getPakan(): Pakan[] { return getItem<Pakan[]>(STORAGE_KEYS.PAKAN, INITIAL_PAKAN); },
  getPakanList(): Pakan[] { return this.getPakan(); },
  savePakan(pakan: Pakan[]) { setItem(STORAGE_KEYS.PAKAN, pakan); },
  savePakanList(pakan: Pakan[]) { this.savePakan(pakan); },

  // Spesies
  getSpesies(): Spesies[] { return getItem<Spesies[]>(STORAGE_KEYS.SPESIES, INITIAL_SPESIES); },
  getSpesiesList(): Spesies[] { return this.getSpesies(); },
  saveSpesies(spesies: Spesies[]) { setItem(STORAGE_KEYS.SPESIES, spesies); },
  saveSpesiesList(spesies: Spesies[]) { this.saveSpesies(spesies); },

  // Pendaftaran
  getPendaftaran(): Pendaftaran[] { return getItem<Pendaftaran[]>(STORAGE_KEYS.PENDAFTARAN, INITIAL_PENDAFTARAN); },
  getPendaftaranList(): Pendaftaran[] { return this.getPendaftaran(); },
  savePendaftaran(pendaftaran: Pendaftaran[]) { setItem(STORAGE_KEYS.PENDAFTARAN, pendaftaran); },
  savePendaftaranList(pendaftaran: Pendaftaran[]) { this.savePendaftaran(pendaftaran); },

  // Rekam Medis
  getRekamMedis(): RekamMedis[] { return getItem<RekamMedis[]>(STORAGE_KEYS.REKAM_MEDIS, INITIAL_REKAM_MEDIS); },
  getRekamMedisList(): RekamMedis[] { return this.getRekamMedis(); },
  saveRekamMedis(rm: RekamMedis[]) { setItem(STORAGE_KEYS.REKAM_MEDIS, rm); },
  saveRekamMedisList(rm: RekamMedis[]) { this.saveRekamMedis(rm); },

  // Rawat Inap
  getRawatInap(): RawatInap[] { return getItem<RawatInap[]>(STORAGE_KEYS.RAWAT_INAP, INITIAL_RAWAT_INAP); },
  getRawatInapList(): RawatInap[] { return this.getRawatInap(); },
  saveRawatInap(inap: RawatInap[]) { setItem(STORAGE_KEYS.RAWAT_INAP, inap); },
  saveRawatInapList(inap: RawatInap[]) { this.saveRawatInap(inap); },

  // Janji Temu
  getJanjiTemu(): JanjiTemu[] { return getItem<JanjiTemu[]>(STORAGE_KEYS.JANJI_TEMU, INITIAL_JANJI_TEMU); },
  getJanjiTemuList(): JanjiTemu[] { return this.getJanjiTemu(); },
  saveJanjiTemu(jt: JanjiTemu[]) { setItem(STORAGE_KEYS.JANJI_TEMU, jt); },
  saveJanjiTemuList(jt: JanjiTemu[]) { this.saveJanjiTemu(jt); },

  // Vaksinasi
  getVaksinasi(): RiwayatVaksinasi[] { return getItem<RiwayatVaksinasi[]>(STORAGE_KEYS.VAKSINASI, INITIAL_VAKSINASI); },
  getVaksinasiList(): RiwayatVaksinasi[] { return this.getVaksinasi(); },
  saveVaksinasi(vks: RiwayatVaksinasi[]) { setItem(STORAGE_KEYS.VAKSINASI, vks); },
  saveVaksinasiList(vks: RiwayatVaksinasi[]) { this.saveVaksinasi(vks); },

  // Transaksi
  getTransaksi(): Transaksi[] { return getItem<Transaksi[]>(STORAGE_KEYS.TRANSAKSI, INITIAL_TRANSAKSI); },
  getTransaksiList(): Transaksi[] { return this.getTransaksi(); },
  saveTransaksi(trx: Transaksi[]) { setItem(STORAGE_KEYS.TRANSAKSI, trx); },
  saveTransaksiList(trx: Transaksi[]) { this.saveTransaksi(trx); },

  // Pembelian
  getPembelian(): PembelianBarang[] { return getItem<PembelianBarang[]>(STORAGE_KEYS.PEMBELIAN, INITIAL_PEMBELIAN); },
  getPembelianList(): PembelianBarang[] { return this.getPembelian(); },
  savePembelian(pmb: PembelianBarang[]) { setItem(STORAGE_KEYS.PEMBELIAN, pmb); },
  savePembelianList(pmb: PembelianBarang[]) { this.savePembelian(pmb); },

  // Supplier
  getSupplier(): Supplier[] { return getItem<Supplier[]>(STORAGE_KEYS.SUPPLIER, INITIAL_SUPPLIER); },
  getSupplierList(): Supplier[] { return this.getSupplier(); },
  saveSupplier(s: Supplier[]) { setItem(STORAGE_KEYS.SUPPLIER, s); },
  saveSupplierList(s: Supplier[]) { this.saveSupplier(s); },

  // Feedback
  getFeedback(): FeedbackOwner[] { return getItem<FeedbackOwner[]>(STORAGE_KEYS.FEEDBACK, INITIAL_FEEDBACK); },
  getFeedbackList(): FeedbackOwner[] { return this.getFeedback(); },
  saveFeedback(fb: FeedbackOwner[]) { setItem(STORAGE_KEYS.FEEDBACK, fb); },
  saveFeedbackList(fb: FeedbackOwner[]) { this.saveFeedback(fb); },

  // Klinik Info
  getKlinik(): DataKlinik { return getItem<DataKlinik>(STORAGE_KEYS.KLINIK, INITIAL_KLINIK); },
  getKlinikData(): DataKlinik { return this.getKlinik(); },
  saveKlinik(klinik: DataKlinik) { setItem(STORAGE_KEYS.KLINIK, klinik); },
  saveKlinikData(klinik: DataKlinik) { this.saveKlinik(klinik); },

  // Settings
  getSettings(): AppSettings { return getItem<AppSettings>(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS); },
  getAppSettings(): AppSettings { return this.getSettings(); },
  saveSettings(settings: AppSettings) { setItem(STORAGE_KEYS.SETTINGS, settings); },
  saveAppSettings(settings: AppSettings) { this.saveSettings(settings); },

  // Full Database Backup JSON
  exportFullBackupJSON() {
    const data = {
      version: '2.5.0',
      exportedAt: new Date().toISOString(),
      users: this.getUsers(),
      dokter: this.getDokter(),
      pasien: this.getPasien(),
      barang: this.getBarang(),
      tindakan: this.getTindakan(),
      pakan: this.getPakan(),
      spesies: this.getSpesies(),
      pendaftaran: this.getPendaftaran(),
      rekamMedis: this.getRekamMedis(),
      rawatInap: this.getRawatInap(),
      janjiTemu: this.getJanjiTemu(),
      vaksinasi: this.getVaksinasi(),
      transaksi: this.getTransaksi(),
      pembelian: this.getPembelian(),
      supplier: this.getSupplier(),
      feedback: this.getFeedback(),
      klinik: this.getKlinik(),
      settings: this.getSettings()
    };
    return JSON.stringify(data, null, 2);
  },

  // Full Database Restore JSON
  importFullBackupJSON(jsonStr: string): boolean {
    try {
      const data = JSON.parse(jsonStr);
      if (data.users) this.saveUsers(data.users);
      if (data.dokter) this.saveDokter(data.dokter);
      if (data.pasien) this.savePasien(data.pasien);
      if (data.barang) this.saveBarang(data.barang);
      if (data.tindakan) this.saveTindakan(data.tindakan);
      if (data.pakan) this.savePakan(data.pakan);
      if (data.spesies) this.saveSpesies(data.spesies);
      if (data.pendaftaran) this.savePendaftaran(data.pendaftaran);
      if (data.rekamMedis) this.saveRekamMedis(data.rekamMedis);
      if (data.rawatInap) this.saveRawatInap(data.rawatInap);
      if (data.janjiTemu) this.saveJanjiTemu(data.janjiTemu);
      if (data.vaksinasi) this.saveVaksinasi(data.vaksinasi);
      if (data.transaksi) this.saveTransaksi(data.transaksi);
      if (data.pembelian) this.savePembelian(data.pembelian);
      if (data.supplier) this.saveSupplier(data.supplier);
      if (data.feedback) this.saveFeedback(data.feedback);
      if (data.klinik) this.saveKlinik(data.klinik);
      if (data.settings) this.saveSettings(data.settings);
      return true;
    } catch (e) {
      console.error('Failed to import backup JSON', e);
      return false;
    }
  },

  // Reset to initial demo data
  resetDemoData() {
    localStorage.clear();
    this.initStorage();
  },

  // Reset database mengosongkan semua data transaksi & operasional, tetap menyimpan User/Password, Dokter, & Master Data
  resetDatabaseKeepUsers() {
    this.savePasien([]);
    this.savePendaftaran([]);
    this.saveRekamMedis([]);
    this.saveRawatInap([]);
    this.saveJanjiTemu([]);
    this.saveVaksinasi([]);
    this.saveTransaksi([]);
    this.savePembelian([]);
    this.saveFeedback([]);
    this.saveWhatsAppLogs([]);
  }
};

export const backupToJSON = () => {
  const jsonStr = storageService.exportFullBackupJSON();
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `VetCare_Database_Backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

export const restoreFromJSON = (file: File, onSuccess: () => void) => {
  const reader = new FileReader();
  reader.onload = (e) => {
    const text = e.target?.result as string;
    if (text) {
      const ok = storageService.importFullBackupJSON(text);
      if (ok) {
        onSuccess();
      } else {
        alert('Format file JSON tidak valid!');
      }
    }
  };
  reader.readAsText(file);
};
